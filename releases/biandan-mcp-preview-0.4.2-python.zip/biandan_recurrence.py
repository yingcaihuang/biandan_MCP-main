"""Materialize Biandan's native recurrence fields into occurrence windows."""

from calendar import monthrange
from datetime import date, timedelta
from functools import lru_cache
from hashlib import sha256
import re


MODES = {'custom': 1, 'workdays': 2, 'days_off': 3, 'daily': 4, 'ebbinghaus': 5,
         'weekly_period': 6, 'monthly_period': 7, 'yearly_period': 8}
UNITS = {'day': 0, 'week': 1, 'month': 2, 'year': 3, 'lunar_month': 4, 'lunar_year': 5}
FILTERS = {'all': 0, 'days_off': 1, 'workdays': 2}
MAX_OCCURRENCES = 1000


def encode_rule(rule):
    mode = rule.get('mode')
    if mode not in MODES:
        raise ValueError('Unsupported repeat mode.')
    span = rule.get('duration_days', 1)
    if mode != 'custom' and any(key in rule for key in ('unit', 'interval', 'dates', 'day_filter')):
        raise ValueError('Unit, interval, dates and day_filter apply to custom repeat rules.')
    unit = rule.get('unit', 'day')
    interval = rule.get('interval', 1)
    selector = rule.get('day_filter', 'all')
    dates = set(rule.get('dates', ()))
    if unit not in UNITS or selector not in FILTERS or not 1 <= interval <= 366 or not 1 <= span <= 366:
        raise ValueError('Invalid repeat unit, interval, day filter or duration.')
    unit_id = UNITS[unit]
    if (unit_id != 0) != bool(dates):
        raise ValueError('Selected dates are required for weekly, monthly and yearly custom rules.')
    if unit in ('year', 'lunar_year'):
        for selected in dates:
            if not re.fullmatch(r'[0-9]{2}-[0-9]{2}', selected):
                raise ValueError('Yearly dates use MM-DD.')
            month, day = map(int, selected.split('-'))
            if unit == 'year':
                date(2000, month, day)
            elif not (1 <= month <= 12 and 1 <= day <= 30):
                raise ValueError('Invalid lunar month or day.')
    elif dates:
        lower, upper = {'week': (0, 6), 'month': (1, 32), 'lunar_month': (1, 30)}[unit]
        if any(selected not in {str(n) for n in range(lower, upper + 1)} for selected in dates):
            raise ValueError('Selected dates are out of range for this repeat unit.')
    return {'loopSet': MODES[mode], 'loopUnit': unit_id + FILTERS[selector] * 100,
            'loopBaseNumber': interval, 'loopDate': ','.join(sorted(dates)), 'duration': span}


def view_rule(row):
    mode = row.get('loopSet') or 0
    if not mode:
        return None
    mode_name = next((key for key, value in MODES.items() if value == mode), 'unknown')
    data = {'mode': mode_name, 'duration_days': row.get('duration') or 1}
    if mode_name == 'custom':
        selector, unit = divmod(row.get('loopUnit') or 0, 100)
        data.update(unit=next((key for key, value in UNITS.items() if value == unit), 'unknown'),
                    day_filter=next((key for key, value in FILTERS.items() if value == selector), 'unknown'),
                    interval=row.get('loopBaseNumber') or 1,
                    dates=[item for item in (row.get('loopDate') or '').split(',') if item])
    return data


def occurrence_id(task_id, start_date):
    digest = sha256(f'{task_id}:{start_date}'.encode('ascii')).digest()
    return str((1 << 51) + (int.from_bytes(digest[:8], 'big') % (1 << 51)))


def months(start, end, interval):
    first = start.year * 12 + start.month - 1
    last = end.year * 12 + end.month - 1
    for index in range(first, last + 1, interval):
        year, month = divmod(index, 12)
        yield date(year, month + 1, 1)


def lunar_months():
    """Use the same lunar year bits as chineseCalendar.ets."""
    first = date(1900, 1, 31)
    for year, year_bits in enumerate(LUNAR_YEARS, start=1900):
        leap = year_bits & 15
        for month in range(1, 13):
            days = 29 + bool(year_bits & (0x10000 >> month))
            yield year, month, first, days
            first += timedelta(days=days)
            if month == leap:
                days = 29 + bool(year_bits & 0x10000)
                yield year, month, first, days
                first += timedelta(days=days)


@lru_cache(maxsize=1)
def lunar_calendar():
    return tuple(lunar_months())


def lunar_dates(start, end, unit, interval, selected):
    calendar = lunar_calendar()
    anchor_year, anchor_month, _, _ = next(entry for entry in reversed(calendar) if entry[2] <= start)
    anchor = anchor_year * 12 + anchor_month
    for year, month, first, days in calendar:
        if first > end:
            break
        offset = year * 12 + month - anchor
        if offset < 0:
            continue
        if unit == 'lunar_month' and offset % interval == 0:
            for day in map(int, selected):
                if day <= days:
                    yield first + timedelta(days=day - 1)
        if unit == 'lunar_year' and (year - anchor_year) % interval == 0:
            for day in range(1, days + 1):
                if f'{month:02}-{day:02}' in selected:
                    yield first + timedelta(days=day - 1)


def generate_dates(start, end, mode, unit, interval, selected, week_start):
    if mode == 'ebbinghaus':
        offsets = (0, 1, 2, 4, 6, 14, *range(29, (end - start).days + 1, 15))
        for offset in offsets:
            if offset <= (end - start).days:
                yield start + timedelta(days=offset)
    elif mode == 'weekly_period' or unit == 'week':
        sunday = (start.weekday() + 1) % 7
        offset = (sunday - week_start) % 7 if mode == 'weekly_period' else sunday - week_start
        first = start - timedelta(days=offset)
        for delta in range(0, (end - first).days + 1, 7 * interval):
            week = first + timedelta(days=delta)
            if mode == 'weekly_period':
                yield week
            else:
                for day in range(7):
                    if str((day + week_start) % 7) in selected:
                        yield week + timedelta(days=day)
    elif mode == 'monthly_period' or unit == 'month':
        for first in months(start, end, interval):
            if mode == 'monthly_period':
                yield first
            else:
                for day in map(int, selected):
                    # JavaScript Date.setDate carries an oversized day into the next month.
                    actual = monthrange(first.year, first.month)[1] if day == 32 else day
                    yield first + timedelta(days=actual - 1)
    elif mode == 'yearly_period' or unit == 'year':
        for year in range(start.year, end.year + 1, interval):
            if mode == 'yearly_period':
                yield date(year, 1, 1)
            else:
                for value in selected:
                    month, day = map(int, value.split('-'))
                    if day <= monthrange(year, month)[1]:
                        yield date(year, month, day)
    elif unit in ('lunar_month', 'lunar_year'):
        yield from lunar_dates(start, end, unit, interval, selected)
    else:
        for offset in range(0, (end - start).days + 1, interval):
            yield start + timedelta(days=offset)


def recurrence_windows(row, *, week_start=0, china_makeup=False, from_date=None, allow_empty=False):
    start = date.fromisoformat(row['startTime'])
    end = date.fromisoformat(row['endTime'])
    if not date(1900, 1, 31) <= start <= end <= date(2100, 12, 31):
        raise ValueError('Repeat dates must be between 1900-01-31 and 2100-12-31.')
    rule = view_rule(row)
    mode = rule['mode']
    unit = rule.get('unit')
    interval = rule.get('interval', 1)
    selected = set(rule.get('dates', ()))
    selector = mode if mode in ('workdays', 'days_off') else rule.get('day_filter', 'all')
    if china_makeup and selector != 'all' and not date(2024, 1, 1) <= start <= end <= date(2026, 12, 31):
        raise ValueError('Bundled Chinese make-up day data covers 2024–2026. Use regular weekends for other dates.')
    period = mode.endswith('_period')
    dates = set()
    for day in generate_dates(start, end, mode, unit, interval, selected, week_start):
        if day > end or (not period and day < start) or (from_date is not None and day < from_date):
            continue
        holiday = day.weekday() >= 5
        if china_makeup and (day.year, day.month, day.day) in CHINA_MAKEUP:
            holiday = not holiday
        if (selector == 'days_off' and not holiday) or (selector == 'workdays' and holiday):
            continue
        dates.add(day)
        if len(dates) > MAX_OCCURRENCES:
            raise ValueError(f'A single operation can generate at most {MAX_OCCURRENCES} occurrences. Shorten the date range.')
    if not dates and not allow_empty:
        raise ValueError('The selected rule produces no occurrences in this date range.')
    result = []
    for day in sorted(dates):
        if mode == 'weekly_period':
            last = day + timedelta(days=6)
        elif mode == 'monthly_period':
            last = day.replace(day=monthrange(day.year, day.month)[1])
        elif mode == 'yearly_period':
            last = day.replace(month=12, day=31)
        else:
            last = day + timedelta(days=rule['duration_days'] - 1)
        if last > date(2100, 12, 31):
            raise ValueError('An occurrence would end beyond 2100-12-31.')
        if (day, row['validStartTime']) > (last, row['validEndTime']):
            raise ValueError('At least one occurrence ends before it starts.')
        result.append({'startTime': day.isoformat(), 'endTime': last.isoformat(),
                       'validStartTime': row['validStartTime'], 'validEndTime': row['validEndTime']})
    return result


# Year bits from commons/utils/src/main/ets/utils/chineseCalendar.ets.
LUNAR_YEARS = (
    0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
    0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
    0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
    0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
    0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
    0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5b0, 0x14573, 0x052b0, 0x0a9a8, 0x0e950, 0x06aa0,
    0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
    0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b6a0, 0x195a6,
    0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
    0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x05ac0, 0x0ab60, 0x096d5, 0x092e0,
    0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
    0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
    0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
    0x05aa0, 0x076a3, 0x096d0, 0x04afb, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
    0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0,
    0x14b63, 0x09370, 0x049f8, 0x04970, 0x064b0, 0x168a6, 0x0ea50, 0x06b20, 0x1a6c4, 0x0aae0,
    0x0a2e0, 0x0d2e3, 0x0c960, 0x0d557, 0x0d4a0, 0x0da50, 0x05d55, 0x056a0, 0x0a6d0, 0x055d4,
    0x052d0, 0x0a9b8, 0x0a950, 0x0b4a0, 0x0b6a6, 0x0ad50, 0x055a0, 0x0aba4, 0x0a5b0, 0x052b0,
    0x0b273, 0x06930, 0x07337, 0x06aa0, 0x0ad50, 0x14b55, 0x04b60, 0x0a570, 0x054e4, 0x0d160,
    0x0e968, 0x0d520, 0x0daa0, 0x16aa6, 0x056d0, 0x04ae0, 0x0a9d4, 0x0a2d0, 0x0d150, 0x0f252,
    0x0d520,
)

# Holiday/weekend adjustments from holidayChecker.ets.
CHINA_MAKEUP = frozenset({
    (2024, 1, 1), (2024, 2, 4), (2024, 2, 12), (2024, 2, 13), (2024, 2, 14),
    (2024, 2, 15), (2024, 2, 16), (2024, 2, 18), (2024, 4, 4), (2024, 4, 5),
    (2024, 4, 7), (2024, 4, 28), (2024, 5, 1), (2024, 5, 2), (2024, 5, 3),
    (2024, 5, 11), (2024, 6, 10), (2024, 9, 14), (2024, 9, 16), (2024, 9, 17),
    (2024, 9, 29), (2024, 10, 1), (2024, 10, 2), (2024, 10, 3), (2024, 10, 4),
    (2024, 10, 7), (2024, 10, 12), (2025, 1, 1), (2025, 1, 26), (2025, 1, 28),
    (2025, 1, 29), (2025, 1, 30), (2025, 1, 31), (2025, 2, 3), (2025, 2, 4),
    (2025, 2, 8), (2025, 4, 4), (2025, 4, 27), (2025, 5, 1), (2025, 5, 2),
    (2025, 5, 5), (2025, 6, 2), (2025, 9, 28), (2025, 10, 1), (2025, 10, 2),
    (2025, 10, 3), (2025, 10, 6), (2025, 10, 7), (2025, 10, 8), (2025, 10, 11),
    (2026, 1, 1), (2026, 1, 2), (2026, 1, 4), (2026, 2, 14), (2026, 2, 16),
    (2026, 2, 17), (2026, 2, 18), (2026, 2, 19), (2026, 2, 20), (2026, 2, 23),
    (2026, 2, 28), (2026, 4, 6), (2026, 5, 1), (2026, 5, 4), (2026, 5, 5),
    (2026, 5, 9), (2026, 6, 19), (2026, 9, 20), (2026, 9, 25), (2026, 10, 1),
    (2026, 10, 2), (2026, 10, 5), (2026, 10, 6), (2026, 10, 7), (2026, 10, 10),
})
