"""Standalone client for Biandan Online's Huawei sync transport."""

import argparse
import base64
import getpass
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import secrets
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
import warnings
import webbrowser


DATA_URL = "https://driveapis.cloud.huawei.com.cn/sync/v1/rongqi"
OAUTH_URL = "https://oauth-login.cloud.huawei.com/oauth2/v3"
WEB_CLIENT_ID = "5765880207852987515"
WEB_REDIRECT_URI = "https://www.biandangroup.com/#/biandan_online"
RELAY_CALLBACK = "http://127.0.0.1:42681/biandan/callback"
RELAY_STATE_PREFIX = "biandan-local-v1."
KINDS = ("Task", "showTask", "favorites", "tomato")
RECORD_FIELDS = "kind,id,attributes,createdTime,editedTime,version"
LIST_FIELDS = f"nextCursor,records({RECORD_FIELDS})"


class CloudError(Exception):
    def __init__(self, message, status=None, *, code=None):
        super().__init__(message)
        self.status = status
        self.code = code


class AuthorizationDenied(CloudError):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def request_json(method, url, headers=None, body=None):
    request = Request(url, data=body, headers=headers or {}, method=method)
    try:
        with build_opener(NoRedirect()).open(request, timeout=25) as response:
            raw = response.read()
    except HTTPError as error:
        code = None
        with error:
            if error.code == 401:
                try:
                    failure = json.loads(error.read(4096))
                except (OSError, ValueError):
                    failure = None
                if isinstance(failure, dict) and failure.get("error") == "reauthorization_required":
                    code = "reauthorization_required"
        raise CloudError(f"{method} failed with HTTP {error.code}", error.code, code=code) from None
    except (URLError, TimeoutError, OSError):
        raise CloudError(f"{method} could not reach the service or timed out") from None
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        raise CloudError("Service returned invalid JSON") from None
    if not isinstance(data, dict) or data.get("errors") or data.get("error"):
        raise CloudError("Service returned an error or an unexpected response")
    return data


def hidden_input(prompt):
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        try:
            return getpass.getpass(prompt).strip()
        except getpass.GetPassWarning:
            raise CloudError("Enter credentials in a local interactive terminal") from None


def callback_code(callback_url, redirect_uri, state):
    expected = urlsplit(redirect_uri)
    received = urlsplit(callback_url)
    if (expected.scheme, expected.netloc, expected.path) != (received.scheme, received.netloc, received.path):
        raise CloudError("OAuth callback does not match the registered callback")
    route, _, hash_query = received.fragment.partition("?")
    if route != expected.fragment or (not expected.fragment and received.fragment):
        raise CloudError("OAuth callback does not match the registered callback route")
    query = parse_qs(received.query, keep_blank_values=True)
    for key, values in parse_qs(hash_query, keep_blank_values=True).items():
        query.setdefault(key, []).extend(values)
    states = query.get("state", [])
    if len(states) != 1 or not secrets.compare_digest(states[0].encode(), state.encode()):
        raise CloudError("OAuth state did not match this login")
    if "error" in query:
        raise AuthorizationDenied("Huawei did not grant authorization")
    codes = query.get("code", [])
    if len(codes) != 1 or not codes[0]:
        raise CloudError("Authorization code missing from OAuth callback")
    return codes[0]


def open_authorization_page(url):
    if not webbrowser.open(url):
        print(f"Open in your local browser:\n{url}", file=sys.stderr)


def receive_loopback_code(url, redirect_uri, state, timeout=180):
    callback = urlsplit(redirect_uri)
    captured = {}

    class CallbackHandler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            # Request URLs contain the authorization code.
            pass

        def do_GET(self):
            path = urlsplit(self.path)
            if self.headers.get("Host") != callback.netloc or path.path != callback.path:
                self.send_error(404)
                return
            try:
                captured["code"] = callback_code(
                    f"{callback.scheme}://{callback.netloc}{self.path}", redirect_uri, state
                )
            except AuthorizationDenied as error:
                captured["error"] = error
                self.send_error(400, "Huawei did not grant authorization")
                return
            except CloudError:
                self.send_error(400, "Authorization callback rejected")
                return
            body = b"Biandan received the authorization callback. You can close this page."
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def setup(self):
            super().setup()
            self.connection.settimeout(3)

    try:
        with HTTPServer(("127.0.0.1", callback.port), CallbackHandler) as server:
            open_authorization_page(url)
            deadline = time.monotonic() + timeout
            while not captured:
                left = deadline - time.monotonic()
                if left <= 0:
                    raise CloudError("Timed out waiting for Huawei authorization")
                server.timeout = left
                server.handle_request()
    except OSError:
        raise CloudError("Cannot receive the OAuth callback on the registered local port") from None
    if "error" in captured:
        raise captured["error"]
    return captured["code"]


def exchange_authorization(client_id, redirect_uri, scope="openid profile", *, offline=False):
    callback = urlsplit(redirect_uri)
    if not client_id or (
        not callback.hostname or callback.username is not None
        or callback.query
        or (callback.fragment and (
            callback.scheme != "https" or not callback.fragment.startswith("/") or "?" in callback.fragment
        ))
        or not (
            callback.scheme == "https"
            or (callback.scheme == "http" and callback.hostname in {"127.0.0.1", "::1"})
        )
    ):
        raise CloudError("Set the client ID and the registered HTTPS or loopback callback URI")

    verifier = secrets.token_urlsafe(48)
    state = secrets.token_urlsafe(32)
    use_web_relay = redirect_uri == WEB_REDIRECT_URI
    if use_web_relay:
        state = RELAY_STATE_PREFIX + state
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": scope,
        "state": state,
        "code_challenge": challenge.decode().rstrip("="),
        "code_challenge_method": "S256",
    }
    if offline:
        params["access_type"] = "offline"
    url = f"{OAUTH_URL}/authorize?{urlencode(params)}"
    if use_web_relay:
        code = receive_loopback_code(url, RELAY_CALLBACK, state)
    elif callback.scheme == "http" and callback.hostname == "127.0.0.1":
        if not callback.port or not callback.path:
            raise CloudError("Register a loopback redirect URI with an explicit port and path")
        code = receive_loopback_code(url, redirect_uri, state)
    else:
        open_authorization_page(url)
        code = callback_code(hidden_input("Paste the callback URL here: "), redirect_uri, state)
    form = urlencode({
        "grant_type": "authorization_code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code": code,
        "code_verifier": verifier,
    }).encode()
    return request_json(
        "POST", f"{OAUTH_URL}/token", {"Content-Type": "application/x-www-form-urlencoded"}, form
    )


def authorize(client_id, redirect_uri, scope="openid profile"):
    reply = exchange_authorization(client_id, redirect_uri, scope)
    token = reply.get("access_token")
    if not isinstance(token, str) or not token:
        raise CloudError("Huawei returned no access token")
    return token


def authorize_from_environment():
    return authorize(
        os.environ.get("BIANDAN_CLIENT_ID", WEB_CLIENT_ID),
        os.environ.get("BIANDAN_REDIRECT_URI", WEB_REDIRECT_URI),
        os.environ.get("BIANDAN_SCOPE", "openid profile"),
    )


class BiandanCloud:
    def __init__(self, token, *, authorizer=None):
        if authorizer is None and (not token or any(character.isspace() for character in token)):
            raise CloudError("A valid Huawei access token is required")
        self.token = token
        self.authorizer = authorizer

    @staticmethod
    def record_path(kind, record_id=None):
        if kind not in KINDS:
            raise CloudError("Unsupported record kind")
        path = f"/kinds/{kind}/record"
        if record_id is None:
            return path
        if not record_id or record_id in {".", ".."}:
            raise CloudError("A valid cloud record ID is required")
        return f"{path}/{quote(record_id, safe='')}"

    def request(self, method, path, params=None, attributes=None):
        trace = f"07200_02_{time.time_ns() // 1_000_000}_{secrets.randbelow(10**8):08d}"
        headers = {
            "Accept": "application/json",
            "x-hw-sync-env": "dataSync2DP",
            "x-hw-app-version": "16.3.0.001",
            "x-hw-trace-id": trace,
        }
        query = f"?{urlencode(params)}" if params else ""
        body = None
        if attributes is not None:
            if not isinstance(attributes, dict):
                raise CloudError("attributes must be a JSON object")
            headers["Content-Type"] = "application/json"
            body = json.dumps({"attributes": attributes}, ensure_ascii=False, allow_nan=False).encode()
        url = f"{DATA_URL}{path}{query}"
        token = self.authorizer.access_token() if self.authorizer else self.token
        headers["Authorization"] = f"Bearer {token}"
        try:
            return request_json(method, url, headers, body)
        except CloudError as error:
            if error.status != 401 or self.authorizer is None:
                raise
        # Retry only this rejected request. A business operation may already have made other writes.
        headers["Authorization"] = f"Bearer {self.authorizer.access_token(rejected=token)}"
        return request_json(method, url, headers, body)

    def check(self):
        self.request("GET", "/about")
        return {"connected": True}

    def list_page(self, kind, cursor=None, page_size=20):
        if not 1 <= page_size <= 100:
            raise CloudError("Page size must be between 1 and 100")
        params = {"fields": LIST_FIELDS, "pageSize": page_size}
        if cursor:
            params["cursor"] = cursor
        result = self.request("GET", self.record_path(kind), params)
        rows = result.get("records", result.get("recordList"))
        if not isinstance(rows, list):
            raise CloudError("List response did not contain the expected records")
        records = []
        for row in rows:
            record = self.normalize_record(row)
            if not record.get("id"):
                raise CloudError("List response contained a record without an ID")
            if "attributes" not in record:
                record = self.get(kind, record["id"])
            records.append(record)
        return {**result, "records": records}

    @staticmethod
    def normalize_record(row):
        if not isinstance(row, dict):
            raise CloudError("Service returned an unexpected record")
        record = dict(row)
        record_id = row.get("recordID") or row.get("id")
        if record_id is not None:
            record["id"] = str(record_id)
        if not isinstance(row.get("attributes"), dict):
            record.pop("attributes", None)
            if isinstance(row.get("fields"), dict):
                record["attributes"] = {
                    key: item["value"] if isinstance(item, dict) and "value" in item else item
                    for key, item in row["fields"].items()
                }
        return record

    def get(self, kind, record_id):
        result = self.request("GET", self.record_path(kind, record_id), {"fields": RECORD_FIELDS})
        record = result.get("record", result)
        if record is result and isinstance(result.get("records"), list) and len(result["records"]) == 1:
            record = result["records"][0]
        record = self.normalize_record(record)
        if (
            record.get("id") != record_id
            or type(record.get("version")) is not int
            or not isinstance(record.get("attributes"), dict)
        ):
            raise CloudError("Get response did not contain the expected ID, version and attributes")
        return record

    def create(self, kind, attributes):
        if not isinstance(attributes, dict) or not attributes:
            raise CloudError("Create requires a nonempty attributes object")
        return self.request("POST", self.record_path(kind), {"fields": RECORD_FIELDS}, attributes)

    def update(self, kind, record_id, baseversion, changes, *, reparent=False):
        immutable = {"id2"} if reparent and kind == "showTask" else {"id1", "id2"}
        if (
            not isinstance(changes, dict) or not changes
            or immutable.intersection(changes)
            or (kind == "favorites" and "id3" in changes)
            or (kind == "tomato" and "time" in changes)
        ):
            raise CloudError("Patch must be a nonempty JSON object without record identity fields")
        current = self.get(kind, record_id)
        if current["version"] != baseversion:
            raise CloudError("Record version changed; re-read before updating", 409)
        attributes = {**current["attributes"], **changes}
        return self.request(
            "PATCH", self.record_path(kind, record_id), {"baseversion": baseversion}, attributes
        )

    def delete(self, kind, record_id, baseversion):
        current = self.get(kind, record_id)
        if current["version"] != baseversion:
            raise CloudError("Record version changed; re-read before deleting", 409)
        if kind == "favorites" and str(current["attributes"].get("id3")) == "1":
            raise CloudError("The default list cannot be deleted")
        return self.request("DELETE", self.record_path(kind, record_id), {"baseversion": baseversion})


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    auth = parser.add_mutually_exclusive_group()
    auth.add_argument("--oauth", action="store_true", help="Authorize interactively for this command")
    auth.add_argument("--prompt-token", action="store_true", help="Read a token from the local terminal")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("check")
    for command in ("list", "get", "create", "update", "delete"):
        sub = commands.add_parser(command)
        sub.add_argument("kind", choices=KINDS)
        if command == "list":
            sub.add_argument("--cursor")
            sub.add_argument("--page-size", type=int, default=20)
        if command in {"get", "update", "delete"}:
            sub.add_argument("record_id")
        if command in {"update", "delete"}:
            sub.add_argument("baseversion", type=int)
        if command in {"create", "update"}:
            sub.add_argument("json_file", type=Path)
    return parser.parse_args()


def main():
    args = parse_args()
    try:
        if args.oauth:
            token = authorize_from_environment()
        elif args.prompt_token:
            token = hidden_input("Huawei access token: ")
        else:
            token = os.environ.get("BIANDAN_TOKEN", "")
        client = BiandanCloud(token)
        if args.command == "check":
            result = client.check()
        elif args.command == "list":
            result = client.list_page(args.kind, args.cursor, args.page_size)
        elif args.command == "get":
            result = client.get(args.kind, args.record_id)
        elif args.command == "delete":
            result = client.delete(args.kind, args.record_id, args.baseversion)
        else:
            attributes = json.loads(args.json_file.read_text(encoding="utf-8-sig"))
            if not isinstance(attributes, dict):
                raise CloudError("Input must be a JSON object")
            if args.command == "create":
                result = client.create(args.kind, attributes)
            else:
                result = client.update(args.kind, args.record_id, args.baseversion, attributes)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except CloudError as error:
        print(json.dumps({"error": str(error), "status": error.status}), file=sys.stderr)
    except (ValueError, OSError):
        print('{"error":"Invalid configuration or JSON input"}', file=sys.stderr)
    except (EOFError, KeyboardInterrupt):
        print('{"error":"Operation cancelled"}', file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
