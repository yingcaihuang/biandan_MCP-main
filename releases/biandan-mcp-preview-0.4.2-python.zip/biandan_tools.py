"""Business operations shared by the local Biandan CLI and MCP server."""

from datetime import date, datetime, timedelta
import json
import math
import re
import time

from biandan_cloud import CloudError
from biandan_recurrence import encode_rule, occurrence_id as derived_id, recurrence_windows, view_rule


class ToolError(Exception):
    def __init__(self, message, **details):
        super().__init__(message)
        self.details = details


def calendar_date(value):
    try:
        if date.fromisoformat(value).isoformat() == value:
            return value
    except ValueError:
        pass
    raise ToolError("Use a date in YYYY-MM-DD format.")


def business_id(value):
    if not re.fullmatch(r"[1-9][0-9]{0,15}", value) or int(value) > 2**53 - 1:
        raise ToolError("Use the positive numeric business ID returned by a Biandan tool.")
    return value


def clock_time(value):
    if not re.fullmatch(r"(?:[01][0-9]|2[0-3]):[0-5][0-9]", value):
        raise ToolError("Use a local time in HH:MM format.")
    return value + ":00"


def decode_content(value):
    if not isinstance(value, str):
        raise ToolError("The stored task content has an unexpected format.")
    try:
        outer = json.loads(value)
    except ValueError:
        return value, [], []
    if not isinstance(outer, list) or not all(isinstance(item, str) for item in outer):
        return value, [], []
    remark, *subtasks = outer or [""]
    try:
        inner = json.loads(remark)
    except ValueError:
        return remark, subtasks, []
    if (
        isinstance(inner, list) and len(inner) == 2 and isinstance(inner[0], str)
        and isinstance(inner[1], list) and all(isinstance(item, str) for item in inner[1])
    ):
        return inner[0], subtasks, inner[1]
    return remark, subtasks, []


def encode_content(remark, subtasks, attachments=()):
    first = json.dumps([remark, list(attachments)], ensure_ascii=False) if attachments else remark
    return json.dumps([first, *subtasks], ensure_ascii=False)


def task_view(record):
    row = record["attributes"]
    remark, subtasks, _ = decode_content(row.get("taskContent", ""))
    flags = row.get("isRemind") or 0
    target = row.get("unitTimeNumber") or 1
    return {
        "task_id": str(row["id1"]),
        "title": row["taskTitle"],
        "remark": remark,
        "subtasks": subtasks,
        "target_count": (target // 100).bit_count() if target >= 100 else target,
        "list_id": str(row.get("id3") or 1),
        "important": bool(row.get("isImportant")),
        "urgent": bool(row.get("isUrgency")),
        "collected": bool(row.get("isCollectible")),
        "repeat_type": row.get("loopSet") or 0,
        "recurrence": view_rule(row),
        "is_habit": (row.get("isLoop") or 0) >= 2,
        "undated": bool(row.get("haveNoTime")),
        "start_date": row.get("startTime"),
        "end_date": row.get("endTime"),
        "start_time": row.get("validStartTime"),
        "end_time": row.get("validEndTime"),
        "completed": bool(row.get("isFinish")),
        "time_reminder": (
            {"date": row.get("remindDate"), "time": row.get("remindTime")} if flags & 1 else None
        ),
        "has_location_reminder": bool(flags & 2),
        "location": (
            {"name": row.get("location") or "", "latitude": row.get("latitude"),
             "longitude": row.get("longitude"), "coordinate_system": "GCJ-02"}
            if row.get("location") or (None not in (row.get("latitude"), row.get("longitude"))
                                       and (row.get("latitude"), row.get("longitude")) != (-1, -1))
            or flags & 2 else None
        ),
    }


def occurrence_view(record, task):
    row = record["attributes"]
    progress = row.get("completedCount") or 0
    target = task["attributes"].get("unitTimeNumber") or 1
    return {
        "occurrence_id": str(row["id2"]),
        "task_id": str(row["id1"]),
        "start_date": row.get("startTime"),
        "end_date": row.get("endTime"),
        "start_time": row.get("validStartTime"),
        "end_time": row.get("validEndTime"),
        "status": "completed" if row.get("isFinish") else "abandoned" if progress < 0 else "pending",
        "completed_at": row.get("recentFinishedTime") if row.get("isFinish") else None,
        "completed_count": (max(progress, 0) // 100).bit_count() if target >= 100 else max(progress, 0),
        "target_count": (target // 100).bit_count() if target >= 100 else target,
        "completed_subtask_indices": [
            index for index in range(20) if (max(progress, 0) // 100) & (1 << index)
        ] if target >= 100 else [],
    }


def page_result(items, limit, offset):
    if not 1 <= limit <= 100 or offset < 0:
        raise ToolError("limit must be 1–100 and offset cannot be negative.")
    end = offset + limit
    return {"items": items[offset:end], "total": len(items), "next_offset": end if end < len(items) else None}


class BiandanTools:
    def __init__(self, cloud, now=datetime.now):
        self.cloud = cloud
        self.now = now

    def records(self, kind):
        cursor = None
        seen = set()
        for _ in range(200):
            page = self.cloud.list_page(kind, cursor, 100)
            yield from page["records"]
            cursor = page.get("nextCursor")
            if not cursor:
                return
            if not isinstance(cursor, str) or cursor in seen:
                raise ToolError(f"Invalid or repeated cursor for {kind}.")
            seen.add(cursor)
        raise ToolError(f"Too many {kind} pages; the operation was stopped before using partial data.")

    def find(self, kind, key, identifier, rows=None, required=True):
        business_id(identifier)
        rows = self.records(kind) if rows is None else rows
        matches = [row for row in rows if str(row["attributes"].get(key)) == identifier]
        if len(matches) > 1:
            raise ToolError(f"Multiple {kind} records share ID {identifier}.")
        if matches:
            return matches[0]
        if required:
            raise ToolError(f"No {kind} record found with ID {identifier}.")
        return None

    def fresh(self, kind, record):
        return self.cloud.get(kind, str(record["id"]))

    def patch(self, kind, record, changes, *, reparent=False):
        changes = {key: value for key, value in changes.items() if record["attributes"].get(key) != value}
        if not changes:
            return record
        self.cloud.update(kind, str(record["id"]), record["version"], changes, reparent=reparent)
        updated = self.fresh(kind, record)
        if any(str(updated["attributes"].get(key)) != str(value) if key == "id1"
               else updated["attributes"].get(key) != value for key, value in changes.items()):
            raise ToolError(f"The requested {kind} update was not confirmed by readback.")
        return updated

    def check_connection(self):
        return self.cloud.check()

    def local_today(self):
        return {"date": self.now().date().isoformat()}

    def list_lists(self):
        lists = [{
            "list_id": str(row["attributes"]["id3"]),
            "name": row["attributes"]["favoritesName"],
            "color": (row["attributes"].get("favoritesColor") or 0) % 100,
            "sort_index": (row["attributes"].get("favoritesColor") or 0) // 100,
        } for row in self.records("favorites")]
        if not any(item["list_id"] == "1" for item in lists):
            lists.append({"list_id": "1", "name": "未分类", "color": 0, "sort_index": 0})
        return {"items": sorted(lists, key=lambda item: (item["sort_index"], int(item["list_id"])))}

    def validate_list(self, list_id):
        if list_id != "1":
            self.find("favorites", "id3", list_id)
        return int(list_id)

    def get_list(self, list_id, include_pending=False, limit=30, offset=0):
        business_id(list_id)
        item = next((item for item in self.list_lists()["items"] if item["list_id"] == list_id), None)
        if item is None:
            raise ToolError(f"No list found with ID {list_id}.")
        if include_pending:
            item["pending_occurrences"] = self.list_occurrences(
                start_date="1900-01-31", end_date="2100-12-31", list_id=list_id,
                status="pending", include_undated=True, limit=limit, offset=offset,
            )
        return item

    def create_list(self, name, color=0, sort_index=None, operation_id=None):
        name = name.strip()
        if not name:
            raise ToolError("A list name is required.")
        identifier = business_id(operation_id) if operation_id is not None else str(time.time_ns() // 1000)
        if identifier == "1":
            raise ToolError("List ID 1 is reserved.")
        existing = self.find("favorites", "id3", identifier, required=False)
        if sort_index is None:
            sort_index = ((existing["attributes"].get("favoritesColor") or 0) // 100 if existing
                          else max((item["sort_index"] for item in self.list_lists()["items"]), default=0) + 1)
        try:
            self.ensure_record("favorites", "id3", identifier, {
                "id3": int(identifier), "favoritesName": name, "favoritesColor": sort_index * 100 + color,
            }, existing)
        except (ToolError, CloudError) as error:
            raise ToolError(str(error), operation_id=identifier,
                            recovery="Retry with the same operation_id and inputs.") from error
        return {**self.get_list(identifier), "operation_id": identifier}

    def update_list(self, list_id, name=None, color=None, sort_index=None):
        if list_id == "1":
            raise ToolError("The default list cannot be edited.")
        if all(value is None for value in (name, color, sort_index)):
            raise ToolError("Provide a list field to change.")
        row = self.fresh("favorites", self.find("favorites", "id3", list_id))
        changes = {}
        if name is not None:
            if not name.strip():
                raise ToolError("A list name is required.")
            changes["favoritesName"] = name.strip()
        if color is not None or sort_index is not None:
            old_sort, old_color = divmod(row["attributes"].get("favoritesColor") or 0, 100)
            changes["favoritesColor"] = (old_sort if sort_index is None else sort_index) * 100 + (
                old_color if color is None else color
            )
        self.patch("favorites", row, changes)
        return self.get_list(list_id)

    def delete_record(self, kind, record):
        try:
            self.cloud.delete(kind, str(record["id"]), record["version"])
        except CloudError as error:
            if error.status != 404:
                raise

    def delete_list(self, list_id, tasks="move_to_default", preview=False):
        if list_id == "1":
            raise ToolError("The default list cannot be deleted.")
        folder = self.find("favorites", "id3", list_id, required=False)
        matches = [row for row in self.records("Task") if str(row["attributes"].get("id3")) == list_id]
        result = {"list_id": list_id, "task_action": tasks,
                  "affected_tasks": [{"task_id": str(row["attributes"]["id1"]),
                                      "title": row["attributes"]["taskTitle"]} for row in matches]}
        if preview:
            return {**result, "preview": True}
        if folder is None and matches:
            raise ToolError("The list no longer exists but tasks still reference it. Move the tasks before retrying.")
        try:
            for row in matches:
                if tasks == "delete_tasks":
                    self.delete_task(str(row["attributes"]["id1"]), scope="series", expected_list=list_id)
                else:
                    self.patch("Task", row, {"id3": 1})
            if folder:
                if any(str(row["attributes"].get("id3")) == list_id for row in self.records("Task")):
                    raise ToolError("Some tasks still reference this list.")
                self.delete_record("favorites", folder)
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), list_id=list_id, may_have_written=True,
                            recovery="Re-read this list and retry the same action.") from error
        return {**result, "deleted": True}

    def delete_task(self, task_id, scope=None, occurrence_id=None, from_date=None, preview=False, *, expected_list=None):
        task = self.find("Task", "id1", task_id, required=False)
        instances = self.task_occurrences(task_id)
        repeating = task and (task["attributes"].get("isLoop") or task["attributes"].get("loopSet"))
        if expected_list is not None and (task is None or str(task["attributes"].get("id3")) != expected_list):
            raise ToolError("This task no longer belongs to the list being deleted.")
        if repeating and scope is None:
            raise ToolError("Choose a repeat deletion scope: occurrence, future_pending or series.")
        if (occurrence_id is not None) != (scope == "occurrence") or (from_date is not None and scope != "future_pending"):
            raise ToolError("occurrence requires occurrence_id; from_date only applies to future_pending.")
        delete_parent = scope in (None, "series") or (not repeating and scope == "occurrence")
        chosen = instances
        if scope == "occurrence":
            business_id(occurrence_id)
            chosen = [row for row in instances if str(row["attributes"].get("id2")) == occurrence_id]
            if not chosen and task and not repeating and instances:
                raise ToolError("The specified occurrence does not belong to this task.")
        if scope == "future_pending":
            start = (calendar_date(from_date), "00:00:00") if from_date is not None else (
                self.now().date().isoformat(), self.now().strftime("%H:%M:%S")
            )
            chosen = [row for row in instances if not row["attributes"].get("isFinish")
                      and (row["attributes"].get("startTime") or "",
                           row["attributes"].get("validStartTime") or "") >= start]
            delete_parent = bool(chosen) and len(chosen) == len(instances)
        if delete_parent and scope == "occurrence" and len(chosen) != len(instances):
            raise ToolError("Additional occurrences exist. Use series deletion to remove the task.")
        result = {
            "task_id": task_id, "title": task["attributes"].get("taskTitle") if task else None,
            "scope": scope or "series", "occurrence_ids": [str(row["attributes"]["id2"]) for row in chosen],
            "deletes_task_definition": bool(task and delete_parent),
        }
        if preview:
            return {**result, "preview": True}
        try:
            for row in chosen:
                self.delete_record("showTask", row)
            if task:
                remaining = self.task_occurrences(task_id)
                if delete_parent:
                    if remaining:
                        raise ToolError("Other occurrences appeared before deletion finished.")
                    self.delete_record("Task", task)
                elif remaining:
                    self.reconcile_task(task, remaining)
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), task_id=task_id, may_have_written=True,
                            recovery="Re-read the task and retry the same deletion scope.") from error
        return {**result, "deleted": True}

    def search_tasks(self, query="", list_id=None, important=None, urgent=None, limit=30, offset=0,
                     habit=None, repeating=None, completed=None, collected=None):
        if list_id is not None:
            business_id(list_id)
        needle = query.strip().casefold()
        items = []
        for record in self.records("Task"):
            item = task_view(record)
            if list_id is not None and item["list_id"] != list_id:
                continue
            if important is not None and item["important"] != important:
                continue
            if urgent is not None and item["urgent"] != urgent:
                continue
            if any(wanted is not None and actual != wanted for wanted, actual in (
                (habit, item["is_habit"]), (repeating, bool(item["repeat_type"])),
                (completed, item["completed"]), (collected, item["collected"]),
            )):
                continue
            searchable = [item["title"], item["remark"], *item["subtasks"]]
            if not needle or any(needle in text.casefold() for text in searchable):
                items.append(item)
        items.sort(key=lambda item: (item["completed"], -int(item["task_id"])))
        return page_result(items, limit, offset)

    def get_task(self, task_id):
        return task_view(self.fresh("Task", self.find("Task", "id1", task_id)))

    def list_occurrences(
        self, start_date=None, end_date=None, status="pending", task_id=None,
        list_id=None, include_undated=False, important=None, urgent=None, limit=30, offset=0,
        query="", habit=None, repeating=None, collected=None, time_query=None, include_summary=False,
    ):
        if status not in {"pending", "completed", "abandoned", "all"}:
            raise ToolError("Unsupported occurrence status.")
        current = self.now()
        time_window = None
        if time_query is not None:
            if start_date is not None or end_date is not None:
                raise ToolError("Use either time_query or explicit dates.")
            offsets = {"today": (0, 0), "tomorrow": (1, 1),
                       "last7day": (-6, 0), "next7day": (0, 6)}
            if time_query in offsets:
                first, last = offsets[time_query]
                start_date = (current.date() + timedelta(days=first)).isoformat()
                end_date = (current.date() + timedelta(days=last)).isoformat()
            else:
                first, last = (-1, 0) if time_query == "last24hour" else (0, 1)
                time_window = tuple(current + timedelta(days=offset) for offset in (first, last))
                start_date, end_date = (item.date().isoformat() for item in time_window)
        start = calendar_date(start_date) if start_date is not None else current.date().isoformat()
        end = calendar_date(end_date) if end_date is not None else start
        if end < start:
            raise ToolError("end_date cannot be earlier than start_date.")
        if task_id is not None:
            business_id(task_id)
        if list_id is not None:
            business_id(list_id)
        tasks = {}
        for task in self.records("Task"):
            item = task_view(task)
            identifier = item["task_id"]
            if identifier in tasks:
                raise ToolError(f"Multiple tasks share ID {identifier}.")
            tasks[identifier] = (task, item)
        items = []
        needle = query.strip().casefold()
        for occurrence in self.records("showTask"):
            identifier = str(occurrence["attributes"].get("id1"))
            if identifier not in tasks or (task_id is not None and identifier != task_id):
                continue
            task, summary = tasks[identifier]
            if list_id is not None and summary["list_id"] != list_id:
                continue
            if important is not None and summary["important"] != important:
                continue
            if urgent is not None and summary["urgent"] != urgent:
                continue
            if any(wanted is not None and actual != wanted for wanted, actual in (
                (habit, summary["is_habit"]), (repeating, bool(summary["repeat_type"])),
                (collected, summary["collected"]),
            )):
                continue
            if needle and not any(needle in text.casefold() for text in
                                  (summary["title"], summary["remark"], *summary["subtasks"])):
                continue
            item = occurrence_view(occurrence, task)
            if status != "all" and item["status"] != status:
                continue
            if status == "completed":
                matches = start <= (item["completed_at"] or "")[:10] <= end
            elif summary["undated"]:
                matches = include_undated
            else:
                matches = (item["start_date"] or "") <= end and (item["end_date"] or "") >= start
            if matches and time_window and (status == "completed" or not summary["undated"]):
                if status == "completed":
                    first = last = item["completed_at"]
                else:
                    first = f'{item["start_date"]} {item["start_time"] or "00:00:00"}'
                    last = f'{item["end_date"]} {item["end_time"] or "23:59:59"}'
                matches = (first <= time_window[1].isoformat(sep=" ", timespec="seconds")
                           and last >= time_window[0].isoformat(sep=" ", timespec="seconds"))
            if matches:
                items.append({**item, "title": summary["title"], "list_id": summary["list_id"]})
        sort_field = "completed_at" if status == "completed" else "start_date"
        items.sort(key=lambda item: (item[sort_field] or "", item["start_time"] or "", item["occurrence_id"]))
        result = page_result(items, limit, offset)
        if include_summary:
            result["summary"] = {state: sum(item["status"] == state for item in items)
                                 for state in ("pending", "completed", "abandoned")}
        return result

    @staticmethod
    def date_window(start_date, end_date, start_time, end_time):
        start = calendar_date(start_date)
        end = calendar_date(end_date) if end_date is not None else start
        first = clock_time(start_time) if start_time is not None else "00:00:00"
        last = clock_time(end_time) if end_time is not None else "23:59:00"
        if (start, first) > (end, last):
            raise ToolError("The end of the task cannot be earlier than its start.")
        return {"startTime": start, "endTime": end, "validStartTime": first, "validEndTime": last}

    def create_task(
        self, title, start_date=None, end_date=None, start_time=None, end_time=None,
        list_id="1", remark="", subtasks=None, important=False, urgent=False,
        reminder_date=None, reminder_time=None, operation_id=None, repeat_rule=None,
        habit=False, target_count=None, location=None, week_start=0, china_makeup=False,
    ):
        title = title.strip()
        if not title:
            raise ToolError("A task title is required.")
        subtasks = [] if subtasks is None else subtasks
        if len(subtasks) > 20 or any(not item.strip() for item in subtasks):
            raise ToolError("Provide no more than 20 non-empty subtask titles.")
        undated = start_date is None
        if undated and any(value is not None for value in (end_date, start_time, end_time, reminder_time, repeat_rule)):
            raise ToolError("Provide start_date for a scheduled task or a time reminder.")
        if (repeat_rule is not None and end_date is None) or (habit and repeat_rule is None):
            raise ToolError("Repeating tasks require end_date; habits require a repeat rule.")
        window = self.date_window(start_date or "1970-01-01", "2100-12-31" if undated else end_date,
                                  start_time, end_time)
        if (reminder_date is None) != (reminder_time is None):
            raise ToolError("Provide both reminder_date and reminder_time, or neither.")
        task_id = business_id(operation_id) if operation_id is not None else str(time.time_ns() // 1000)
        if subtasks and target_count is not None:
            raise ToolError("Choose either subtasks or a numeric target.")
        task = {
            **window, "id1": task_id, "taskTitle": title,
            "taskContent": encode_content(remark, subtasks), "id3": self.validate_list(list_id),
            "isCollectible": 0, "isImportant": int(important), "isUrgency": int(urgent),
            "isLoop": 0, "haveNoTime": int(undated),
            "unitTimeNumber": ((1 << len(subtasks)) - 1) * 100 if subtasks else (target_count or 1),
            "loopSet": 0, "loopBaseNumber": 1, "loopUnit": 0, "loopDate": "", "duration": 0,
            "isRemind": int(reminder_time is not None),
            "remindDate": calendar_date(reminder_date) if reminder_date is not None else window["startTime"],
            "remindTime": clock_time(reminder_time) if reminder_time is not None else "00:00:00",
            "isFinish": 0, "latitude": -1, "longitude": -1, "location": "",
        }
        if location is not None:
            task.update(self.location_changes(task, **location))
        windows = [window]
        if repeat_rule is not None:
            try:
                task.update(encode_rule(repeat_rule), isLoop=2 if habit else 1)
                windows = recurrence_windows(task, week_start=week_start, china_makeup=china_makeup)
            except ValueError as error:
                raise ToolError(str(error)) from error
        occurrences = [self.new_occurrence(task_id, slot, repeating=repeat_rule is not None) for slot in windows]
        stage = "task"
        try:
            stored = self.find("Task", "id1", task_id, required=False)
            indexed = self.occurrence_index({item["id2"] for item in occurrences})
            if indexed and not stored:
                raise ToolError("A generated occurrence ID is already in use.")
            if any(str(row["attributes"].get("id1")) != task_id for row in indexed.values()):
                raise ToolError("A generated occurrence ID belongs to a different task.")
            self.ensure_record("Task", "id1", task_id, task, stored)
            stage = "occurrence"
            for entry in occurrences:
                self.ensure_record("showTask", "id2", entry["id2"], entry, indexed.get(entry["id2"]))
        except (ToolError, CloudError) as error:
            raise ToolError(
                str(error), operation_id=task_id, stage=stage, may_have_written=True,
                recovery="Re-run with the same operation_id and identical inputs after checking the record.",
            ) from error
        return {"task_id": task_id, "occurrence_id": occurrences[0]["id2"], "operation_id": task_id,
                "occurrences_created": len(occurrences)}

    @staticmethod
    def new_occurrence(task_id, window, *, repeating=True):
        return {**window, "id1": task_id, "id2": derived_id(task_id, window["startTime"]) if repeating else task_id,
                "completedCount": 0, "recentFinishedTime": "", "isFinish": 0}

    def occurrence_index(self, identifiers):
        matches = {}
        for row in self.records("showTask"):
            identifier = str(row["attributes"].get("id2"))
            if identifier in identifiers:
                if identifier in matches:
                    raise ToolError(f"Multiple occurrences share ID {identifier}.")
                matches[identifier] = row
        return matches

    def ensure_record(self, kind, key, identifier, expected, existing):
        if existing is None:
            created = self.cloud.create(kind, expected)
            saved = created.get("saveResults") or []
            if len(saved) == 1 and isinstance(saved[0], dict):
                receipt = self.cloud.normalize_record(saved[0])
                if receipt.get("id"):
                    existing = receipt
            if existing is None:
                existing = self.find(kind, key, identifier)
        actual = self.fresh(kind, existing)["attributes"]
        for key, value in expected.items():
            matches = str(actual.get(key)) == str(value) if key in {"id1", "id2", "id3", "time"} else actual.get(key) == value
            if not matches:
                raise ToolError(f"Stored {kind} does not match the requested creation fields.")

    @staticmethod
    def location_changes(row, name=None, latitude=None, longitude=None, remind=None, clear=False):
        flags = row.get("isRemind") or 0
        if clear:
            if any(value is not None for value in (name, latitude, longitude, remind)):
                raise ToolError("clear cannot be combined with location or reminder values.")
            return {"location": "", "latitude": -1, "longitude": -1, "isRemind": flags & ~2}
        if all(value is None for value in (name, latitude, longitude, remind)):
            raise ToolError("Provide a location, coordinates or reminder setting.")
        if (latitude is None) != (longitude is None):
            raise ToolError("Provide latitude and longitude together.")
        changes = {}
        if name is not None:
            changes["location"] = name.strip()
        if latitude is not None:
            if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
                raise ToolError("Coordinates are outside the valid range.")
            changes.update(latitude=latitude, longitude=longitude)
        if remind is not None:
            lat = changes.get("latitude", row.get("latitude"))
            lon = changes.get("longitude", row.get("longitude"))
            if remind and (lat is None or lon is None or (lat, lon) == (-1, -1)):
                raise ToolError("A location reminder needs an actual map coordinate.")
            changes["isRemind"] = (flags | 2) if remind else (flags & ~2)
        elif (latitude, longitude) == (-1, -1):
            changes["isRemind"] = flags & ~2
        return changes

    def set_location(self, task_id, name=None, latitude=None, longitude=None, remind=None, clear=False):
        current = self.fresh("Task", self.find("Task", "id1", task_id))
        changes = self.location_changes(current["attributes"], name, latitude, longitude, remind, clear)
        return task_view(self.patch("Task", current, changes))

    def set_time_reminder(self, task_id, reminder_date=None, reminder_time=None, enabled=True):
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        row = task["attributes"]
        flags = row.get("isRemind") or 0
        if enabled:
            if reminder_date is None or reminder_time is None:
                raise ToolError("Provide both reminder_date and reminder_time to enable a reminder.")
            changes = {"remindDate": calendar_date(reminder_date), "remindTime": clock_time(reminder_time),
                       "isRemind": flags | 1}
        else:
            if reminder_date is not None or reminder_time is not None:
                raise ToolError("Omit date and time when disabling a reminder.")
            changes = {"isRemind": flags & ~1}
        return task_view(self.patch("Task", task, changes))

    def update_task(self, task_id, title=None, remark=None, important=None, urgent=None, collected=None):
        current = self.fresh("Task", self.find("Task", "id1", task_id))
        changes = {}
        if title is not None:
            if not title.strip():
                raise ToolError("A task title is required.")
            changes["taskTitle"] = title.strip()
        if remark is not None:
            _, subtasks, files = decode_content(current["attributes"].get("taskContent", ""))
            changes["taskContent"] = encode_content(remark, subtasks, files)
        for key, value in (("isImportant", important), ("isUrgency", urgent), ("isCollectible", collected)):
            if value is not None:
                changes[key] = int(value)
        if not changes:
            raise ToolError("Provide at least one field to change.")
        return task_view(self.patch("Task", current, changes))

    def edit_task_goal(self, task_id, subtasks=None, target_count=None):
        if (subtasks is None) == (target_count is None):
            raise ToolError("Choose either subtasks or target_count.")
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        row = task["attributes"]
        remark, previous_titles, attachments = decode_content(row.get("taskContent", ""))
        previous_target = row.get("unitTimeNumber") or 1
        next_titles = [item.strip() for item in subtasks] if subtasks is not None else []
        if len(next_titles) > 20 or any(not item for item in next_titles):
            raise ToolError("Provide no more than 20 non-empty subtask titles.")
        target = ((1 << len(next_titles)) - 1) * 100 if next_titles else (target_count or 1)
        instances = self.task_occurrences(task_id)
        has_progress = any((item["attributes"].get("completedCount") or 0) > 0 or item["attributes"].get("isFinish")
                           for item in instances)
        if has_progress and (previous_target >= 100) != (target >= 100):
            raise ToolError("Changing between count and checklist would reinterpret saved progress.")
        if has_progress and next_titles:
            for index, title in enumerate(next_titles):
                if title in previous_titles and (index >= len(previous_titles) or previous_titles[index] != title):
                    raise ToolError("Do not reorder subtasks with existing history; edit titles in place.")
        try:
            for item in instances:
                data = item["attributes"]
                progress = data.get("completedCount") or 0
                if data.get("isFinish") or progress < 0:
                    # Preserve recorded historical progress and explicit abandonment.
                    continue
                if target >= 100:
                    progress = ((progress // 100) & (target // 100)) * 100
                else:
                    progress = min(progress, target)
                flags = {"completedCount": progress, "isFinish": int(progress >= target)}
                if flags["isFinish"]:
                    flags["recentFinishedTime"] = self.now().strftime("%Y-%m-%d %H:%M:00")
                self.patch("showTask", item, flags)
            task = self.patch("Task", task, {"taskContent": encode_content(remark, next_titles, attachments),
                                             "unitTimeNumber": target})
            task, _ = self.reconcile_task(task, self.task_occurrences(task_id))
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), task_id=task_id, may_have_written=True,
                            recovery="Retry with the same goal and task ID.") from error
        return task_view(task)

    @staticmethod
    def batch(items, call):
        results = []
        for item in items:
            try:
                results.append({"ok": True, "result": call(**item)})
            except ToolError as error:
                results.append({"ok": False, "error": str(error), **error.details})
            except CloudError as error:
                results.append({"ok": False, "error": str(error), "status": error.status})
        return {"items": results, "succeeded": sum(item["ok"] for item in results)}

    def batch_add_tasks(self, tasks):
        return self.batch(tasks, self.create_task)

    def batch_update_tasks(self, tasks):
        def edit(task_id, list_id=None, start_date=None, end_date=None, start_time=None, end_time=None, **metadata):
            if start_date is None and any(value is not None for value in (end_date, start_time, end_time)):
                raise ToolError("Provide start_date to reschedule a task.")
            if list_id is not None:
                self.validate_list(list_id)
            try:
                if start_date is not None:
                    self.reschedule_task(task_id, start_date, end_date, start_time, end_time)
                if list_id is not None:
                    self.move_task(task_id, list_id)
                if metadata:
                    self.update_task(task_id, **metadata)
            except (CloudError, ToolError) as error:
                raise ToolError(str(error), task_id=task_id, may_have_written=True,
                                recovery="Re-read the task and retry the same fields.") from error
            return self.get_task(task_id)
        return self.batch(tasks, edit)

    def batch_complete_occurrences(self, occurrence_ids):
        return self.batch([{"occurrence_id": value} for value in occurrence_ids], self.complete_occurrence)

    def list_focus(self, start_date=None, end_date=None, occurrence_id=None, limit=30, offset=0, include_summary=False):
        if occurrence_id is not None:
            business_id(occurrence_id)
        start = calendar_date(start_date) if start_date is not None else None
        end = calendar_date(end_date) if end_date is not None else None
        if start is not None and end is not None and end < start:
            raise ToolError("end_date cannot precede start_date.")
        results = []
        for record in self.records("tomato"):
            item = self.focus_view(record)
            if occurrence_id is not None and item["occurrence_id"] != occurrence_id:
                continue
            if (start is not None and item["date"] < start) or (end is not None and item["date"] > end):
                continue
            results.append(item)
        results.sort(key=lambda row: int(row["focus_id"]), reverse=True)
        page = page_result(results, limit, offset)
        if include_summary:
            page["summary"] = {key: sum(item[key] for item in results) for key in ("minutes", "good_count", "bad_count")}
        return page

    @staticmethod
    def focus_log(value):
        try:
            data = json.loads(value)
            return data if isinstance(data, dict) else {}
        except (TypeError, ValueError):
            return {}

    @classmethod
    def focus_view(cls, record):
        row = record["attributes"]
        log = cls.focus_log(row.get("log"))
        linked = log.get("eventId")
        identifier = str(row["time"])
        return {"focus_id": identifier, "date": row["date"], "minutes": row.get("minutes", 0),
                "good_count": row.get("goodCount", 0), "bad_count": row.get("badCount", 0),
                "title": log.get("eventTitle", ""), "occurrence_id": str(linked) if linked and linked != -1 else None,
                "started_at": datetime.fromtimestamp(int(identifier) / 1000).isoformat(timespec="seconds")}

    def get_focus(self, focus_id):
        return self.focus_view(self.fresh("tomato", self.find("tomato", "time", focus_id)))

    @staticmethod
    def focus_minutes(value, *, required=False):
        if value is None and not required:
            return None
        if value is None or not math.isfinite(value) or not 1 <= value <= 1440:
            raise ToolError("Focus duration must be between 1 and 1440 minutes.")
        return math.floor(value)

    def create_focus(self, started_at, minutes, title="", good_count=0, bad_count=0, occurrence_id=None):
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?", started_at):
            raise ToolError("Use a local start time in YYYY-MM-DDTHH:MM format.")
        try:
            started = datetime.fromisoformat(started_at)
            identifier = business_id(str(int(started.timestamp() * 1000)))
        except (OverflowError, OSError, ValueError) as error:
            raise ToolError("Invalid local focus start time.") from error
        minutes = self.focus_minutes(minutes, required=True)
        data = {"eventId": -1, "eventType": -1, "eventTitle": title.strip()}
        if occurrence_id is not None:
            linked = self.get_occurrence(occurrence_id)["task"]
            data.update(eventId=int(occurrence_id), eventType=int(linked["list_id"]),
                        eventTitle=title.strip() or linked["title"])
        ended = (started + timedelta(minutes=minutes)).astimezone()
        data["endTime"] = ended.isoformat()
        self.ensure_record("tomato", "time", identifier, {
            "time": int(identifier), "date": started.date().isoformat(), "minutes": minutes,
            "goodCount": good_count, "badCount": bad_count, "log": json.dumps(data, ensure_ascii=False),
        }, self.find("tomato", "time", identifier, required=False))
        return self.get_focus(identifier)

    def update_focus(self, focus_id, title=None, good_count=None, bad_count=None):
        if all(value is None for value in (title, good_count, bad_count)):
            raise ToolError("Provide a field to change.")
        record = self.fresh("tomato", self.find("tomato", "time", focus_id))
        changes = {field: value for field, value in (("goodCount", good_count), ("badCount", bad_count))
                   if value is not None}
        if title is not None:
            original = record["attributes"].get("log")
            data = self.focus_log(original)
            if not data:
                data = {"eventId": -1, "eventType": -1, "endTime": original or ""}
            changes["log"] = json.dumps({**data, "eventTitle": title.strip()}, ensure_ascii=False)
        return self.focus_view(self.patch("tomato", record, changes))

    def delete_focus(self, focus_id):
        record = self.find("tomato", "time", focus_id, required=False)
        if record is not None:
            self.delete_record("tomato", record)
        return {"focus_id": focus_id, "deleted": True}

    def move_task(self, task_id, list_id):
        destination = self.validate_list(list_id)
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        return task_view(self.patch("Task", task, {"id3": destination}))

    def update_recurrence(self, task_id, repeat_rule, from_date=None, start_date=None, end_date=None,
                          start_time=None, end_time=None, habit=None, week_start=0, china_makeup=False,
                          preview=False):
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        row = task["attributes"]
        cutoff = calendar_date(from_date) if from_date is not None else self.now().date().isoformat()
        if row.get("haveNoTime") and (start_date is None or end_date is None):
            raise ToolError("Provide start_date and end_date when converting an undated task.")
        start = start_date if start_date is not None else row["startTime"]
        end = end_date if end_date is not None else row["endTime"]
        window = self.date_window(start, end, start_time or row["validStartTime"][:5], end_time or row["validEndTime"][:5])
        if habit is None:
            habit = (row.get("isLoop") or 0) >= 2
        try:
            changes = {**window, **encode_rule(repeat_rule), "isLoop": 2 if habit else 1, "haveNoTime": 0}
            target = {slot["startTime"]: slot for slot in recurrence_windows(
                changes, from_date=date.fromisoformat(cutoff), allow_empty=True,
                week_start=week_start, china_makeup=china_makeup,
            )}
        except ValueError as error:
            raise ToolError(str(error)) from error
        planned, protected = {}, set()
        existing = self.task_occurrences(task_id)
        for entry in existing:
            fields = entry["attributes"]
            day = fields.get("startTime") or ""
            if fields.get("isFinish") or fields.get("completedCount") or (day < cutoff and not row.get("haveNoTime")):
                protected.add(day)
            else:
                if day in planned:
                    raise ToolError("Multiple pending occurrences share a date; reconcile them before editing the series.")
                planned[day] = entry
        for day in protected:
            target.pop(day, None)
        insert = [self.new_occurrence(task_id, slot) for day, slot in target.items() if day not in planned]
        prune = [record for day, record in planned.items() if day not in target]
        patch = [(planned[day], slot) for day, slot in target.items() if day in planned
                 and any(planned[day]["attributes"].get(key) != value for key, value in slot.items())]
        if not target and not protected:
            raise ToolError("This change would leave the task without any occurrences; adjust dates or delete the task.")
        result = {"task_id": task_id, "from_date": cutoff, "created": len(insert), "rescheduled": len(patch),
                  "removed": len(prune), "protected_dates": len(protected)}
        if preview:
            return {**result, "preview": True}
        try:
            indexed = self.occurrence_index({entry["id2"] for entry in insert}) if insert else {}
            if any(str(record["attributes"].get("id1")) != task_id for record in indexed.values()):
                raise ToolError("A generated occurrence ID is already in use by a different task.")
            for entry in insert:
                self.ensure_record("showTask", "id2", entry["id2"], entry, indexed.get(entry["id2"]))
            for record, slot in patch:
                self.patch("showTask", record, slot)
            task = self.patch("Task", task, changes)
            for record in prune:
                self.delete_record("showTask", record)
            task, _ = self.reconcile_task(task, self.task_occurrences(task_id))
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), task_id=task_id, from_date=cutoff, may_have_written=True,
                            recovery="Re-read, then retry using the same rule and from_date.") from error
        return {**result, "task": task_view(task)}

    def reschedule_task(self, task_id, start_date, end_date=None, start_time=None, end_time=None):
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        row = task["attributes"]
        if row.get("isLoop") or row.get("loopSet"):
            raise ToolError("Rescheduling a repeating series is not supported by this operation.")
        instances = self.task_occurrences(task_id)
        if len(instances) != 1:
            raise ToolError("Rescheduling requires exactly one existing occurrence.")
        instance = self.fresh("showTask", instances[0])
        if instance["attributes"].get("isFinish") or (instance["attributes"].get("completedCount") or 0) < 0:
            raise ToolError("Only pending tasks can be rescheduled.")
        # Keep existing clock times unless the caller explicitly changes them.
        current_start = (instance["attributes"].get("validStartTime") or "00:00:00")[:5]
        current_end = (instance["attributes"].get("validEndTime") or "23:59:00")[:5]
        window = self.date_window(
            start_date, end_date, start_time if start_time is not None else current_start,
            end_time if end_time is not None else current_end,
        )
        task_updated = False
        try:
            task = self.patch("Task", task, {**window, "haveNoTime": 0})
            task_updated = True
            instance = self.patch("showTask", instance, window)
        except (CloudError, ToolError) as error:
            raise ToolError(
                str(error), task_id=task_id, task_confirmed=task_updated, occurrence_confirmed=False,
                recovery="Re-read and retry the same scheduling operation.",
            ) from error
        return {"task": task_view(task), "occurrence": occurrence_view(instance, task)}

    def task_occurrences(self, task_id):
        return [row for row in self.records("showTask") if str(row["attributes"].get("id1")) == task_id]

    def get_occurrence(self, occurrence_id):
        instance = self.fresh("showTask", self.find("showTask", "id2", occurrence_id))
        task_id = str(instance["attributes"]["id1"])
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        return {"task": task_view(task), "occurrence": occurrence_view(instance, task)}

    def reschedule_occurrence(self, occurrence_id, start_date, end_date=None, start_time=None, end_time=None):
        instance = self.fresh("showTask", self.find("showTask", "id2", occurrence_id))
        row = instance["attributes"]
        task_id = str(row["id1"])
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        if not (task["attributes"].get("isLoop") or task["attributes"].get("loopSet")):
            return self.reschedule_task(task_id, start_date, end_date, start_time, end_time)
        if row.get("isFinish") or (row.get("completedCount") or 0) < 0:
            raise ToolError("Only pending occurrences can be rescheduled.")
        span = (date.fromisoformat(row["endTime"]) - date.fromisoformat(row["startTime"])).days
        if end_date is None:
            end_date = (date.fromisoformat(calendar_date(start_date)) + timedelta(days=span)).isoformat()
        changes = self.date_window(start_date, end_date, start_time or row["validStartTime"][:5],
                                   end_time or row["validEndTime"][:5])
        detached_id = derived_id(occurrence_id, "detached")
        clone = {**task["attributes"], **changes, "id1": detached_id, "isLoop": 0, "haveNoTime": 0,
                 "loopSet": 0, "loopUnit": 0, "loopBaseNumber": 1, "loopDate": "", "duration": 0, "isFinish": 0}
        try:
            self.ensure_record("Task", "id1", detached_id, clone,
                               self.find("Task", "id1", detached_id, required=False))
            detached = self.fresh("Task", self.find("Task", "id1", detached_id))
            other_instances = [item for item in self.task_occurrences(task_id) if item["id"] != instance["id"]]
            self.reconcile_task(task, other_instances)
            instance = self.patch("showTask", instance, {**changes, "id1": detached_id}, reparent=True)
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), occurrence_id=occurrence_id, task_id=task_id, detached_task_id=detached_id,
                            may_have_written=True, recovery="Retry rescheduling the same occurrence.") from error
        return {"task": task_view(detached), "occurrence": occurrence_view(instance, detached), "series_task_id": task_id}

    def clear_schedule(self, task_id):
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        row = task["attributes"]
        if row.get("isLoop") or row.get("loopSet"):
            raise ToolError("A repeat series needs scheduled dates.")
        instances = self.task_occurrences(task_id)
        if len(instances) != 1:
            raise ToolError("Clearing a schedule requires exactly one occurrence.")
        window = self.date_window("1970-01-01", "2100-12-31", None, None)
        try:
            item = self.patch("showTask", instances[0], window)
            task = self.patch("Task", task, {**window, "haveNoTime": 1, "isRemind": (row.get("isRemind") or 0) & ~1})
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), task_id=task_id, may_have_written=True,
                            recovery="Retry clearing the same schedule.") from error
        return {"task": task_view(task), "occurrence": occurrence_view(item, task)}

    def reconcile_task(self, task, instances):
        summary = bool(instances) and not any(
            not row["attributes"].get("isFinish") and (row["attributes"].get("completedCount") or 0) >= 0
            for row in instances
        )
        return self.patch("Task", task, {"isFinish": int(summary)}), summary

    def complete_occurrence(self, occurrence_id, completed_at=None):
        return self.update_progress(occurrence_id, completed_at=completed_at)

    def complete_subtask(self, occurrence_id, subtask_index):
        return self.update_progress(occurrence_id, subtask_index)

    def change_progress(self, occurrence_id, action, subtask_index=None, count=None, completed_at=None):
        if (subtask_index is not None) != (action == "uncheck_subtask") or (count is not None) != (action == "set_count"):
            raise ToolError("Supply subtask_index for uncheck_subtask or count for set_count.")
        if completed_at is not None and action != "set_count":
            raise ToolError("completed_at applies to set_count or complete_occurrence.")
        return self.update_progress(occurrence_id, subtask_index, action=action, count=count, completed_at=completed_at)

    def update_progress(self, occurrence_id, subtask_index=None, *, action="complete", count=None, completed_at=None):
        if completed_at is not None:
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", completed_at):
                raise ToolError("Use a local completion time in YYYY-MM-DDTHH:MM format.")
            composed = calendar_date(completed_at[:10]) + " " + clock_time(completed_at[11:])
        else:
            composed = self.now().strftime("%Y-%m-%d %H:%M:00")
        occurrence = self.fresh("showTask", self.find("showTask", "id2", occurrence_id))
        task_id = str(occurrence["attributes"]["id1"])
        task = self.fresh("Task", self.find("Task", "id1", task_id))
        target = task["attributes"].get("unitTimeNumber") or 1
        previous = occurrence["attributes"].get("completedCount") or 0
        progress = target
        if subtask_index is not None:
            _, subtasks, _ = decode_content(task["attributes"].get("taskContent", ""))
            if target < 100 or not 0 <= subtask_index < min(len(subtasks), 20):
                raise ToolError("subtask_index is a zero-based index for a subtask on this occurrence.")
            mask = 1 << subtask_index
            if not (target // 100) & mask:
                raise ToolError("The requested subtask is not present in the stored goal mask.")
            bits = max(previous, 0) // 100
            progress = ((bits & ~mask) if action == "uncheck_subtask" else (bits | mask)) * 100
        if action == "reopen":
            progress = 0
        elif action == "abandon":
            progress = -1
        elif action == "restore":
            progress = 0 if previous < 0 else previous
        elif action == "set_count":
            if target >= 100 or not 0 <= count <= target:
                raise ToolError("Provide a count between 0 and the numeric target on a count-based task.")
            progress = count
        changes = {"isFinish": int(progress >= target)}
        if previous != progress or completed_at is not None:
            changes.update(completedCount=progress, recentFinishedTime=composed)
        try:
            occurrence = self.patch("showTask", occurrence, changes)
            # Re-read all siblings after updating the selected occurrence to mirror the native summary.
            refreshed = self.task_occurrences(task_id)
            if not any(str(row["attributes"].get("id2")) == occurrence_id for row in refreshed):
                raise ToolError("Updated occurrence was missing from the refreshed cloud list.")
            refreshed = [occurrence if str(row["id"]) == str(occurrence["id"]) else row for row in refreshed]
            task, summary = self.reconcile_task(task, refreshed)
        except (CloudError, ToolError) as error:
            raise ToolError(str(error), occurrence_id=occurrence_id, task_id=task_id,
                            recovery="Re-read and retry the same completion to reconcile the summary.") from error
        return {"occurrence": occurrence_view(occurrence, task), "task_completed": summary}
