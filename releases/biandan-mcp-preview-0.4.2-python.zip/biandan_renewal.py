"""Renew the HTTP MCP session without opening the browser again."""

import ctypes
from ctypes import wintypes
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from threading import Lock, Thread
import time
from urllib.parse import urlsplit

from biandan_cloud import (
    CloudError, WEB_CLIENT_ID, WEB_REDIRECT_URI, exchange_authorization, request_json,
)
from biandan_http import state_directory


def windows_protect(data, *, decrypt=False):
    """Use DPAPI scoped to the current Windows user."""
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]

    source = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    incoming = Blob(len(data), source)
    outgoing = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    call = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    call.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                     ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if not call(ctypes.byref(incoming), None, None, None, None, 1, ctypes.byref(outgoing)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(outgoing.data, outgoing.size)
    finally:
        kernel.LocalFree(outgoing.data)


def valid_token(value):
    return (isinstance(value, str) and 0 < len(value) <= 4096
            and value.isascii() and all(33 <= ord(char) <= 126 for char in value))


@contextmanager
def renewal_session():
    """Hold the device credential lock until the shared server exits."""
    directory = state_directory()
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    with (directory / 'huawei-refresh.lock').open('a+b') as lock:
        try:
            if os.name == 'nt':
                import msvcrt
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise CloudError('A Biandan HTTP server already uses this local authorization.') from None
        yield


class RefreshTokenStore:
    def __init__(self, path):
        self.path = Path(path)

    def load(self):
        try:
            with self.path.open('rb') as source:
                data = source.read(16385)
        except FileNotFoundError:
            return None
        if len(data) > 16384:
            raise ValueError('Invalid local refresh credential')
        if os.name == 'nt':
            data = windows_protect(data, decrypt=True)
        token = data.decode('ascii')
        if not token.startswith('{') and not valid_token(token):
            raise ValueError('Invalid local refresh credential')
        return token

    def save(self, token):
        directory = self.path.parent
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        data = token.encode('ascii')
        if os.name == 'nt':
            data = windows_protect(data)
        with NamedTemporaryFile(dir=directory, prefix='.refresh-', delete=False) as target:
            temporary = Path(target.name)
            try:
                target.write(data)
                target.flush()
                os.fsync(target.fileno())
                target.close()
                temporary.replace(self.path)
            finally:
                target.close()
                temporary.unlink(missing_ok=True)

    def clear(self):
        self.path.unlink(missing_ok=True)


class RenewingAuthorization:
    def __init__(self, endpoint, *, store=None, device_gate=False):
        url = urlsplit(endpoint)
        if (url.scheme != 'https' or not url.hostname or url.username is not None
                or url.password is not None or url.query or url.fragment
                or (device_gate and url.path != '/v1/refresh')):
            raise ValueError('The Biandan renewal URL must be an HTTPS endpoint')
        self.endpoint = endpoint
        self.device_gate = device_gate
        self.device_grant = None
        endpoint_id = hashlib.sha256(endpoint.encode('utf-8')).hexdigest()[:24]
        self.store = store if store is not None else RefreshTokenStore(
            state_directory() / f'huawei-refresh-{endpoint_id}'
        )
        self.lock = Lock()
        self.token = None
        self.expires_at = 0
        self.pending_save = None
        self.signing_in = False
        self.sign_in_error = None
        try:
            saved = self.store.load()
            if self.device_gate and saved and saved.startswith('{'):
                cached = json.loads(saved)
                self.refresh_token = cached.get('refresh_token')
                self.device_grant = cached.get('device_grant')
                if not valid_token(self.refresh_token) or not valid_token(self.device_grant):
                    raise ValueError('Invalid local Huawei refresh credential')
            else:
                self.refresh_token = saved
        except (OSError, ValueError):
            raise CloudError('Could not read the local Huawei refresh credential') from None
    def start_sign_in(self):
        Thread(target=self.sign_in, daemon=True).start()
        self.signing_in = True

    def sign_in(self):
        try:
            reply = exchange_authorization(WEB_CLIENT_ID, WEB_REDIRECT_URI, offline=True)
            with self.lock:
                self.accept(reply)
        except (CloudError, OSError, ValueError) as error:
            with self.lock:
                self.sign_in_error = str(error) if isinstance(error, CloudError) else 'Huawei authorization could not be saved'
        finally:
            with self.lock:
                self.signing_in = False

    def persist(self):
        refresh_token, device_grant = self.pending_save
        encoded = (json.dumps({'refresh_token': refresh_token, 'device_grant': device_grant})
                   if self.device_gate and device_grant else refresh_token)
        try:
            self.store.save(encoded)
        except OSError:
            raise CloudError('Could not save the Huawei refresh credential. Check local storage and retry.') from None
        self.refresh_token = refresh_token
        self.device_grant = device_grant
        self.pending_save = None

    def accept(self, reply):
        access_token = reply.get('access_token')
        expires_in = reply.get('expires_in')
        refresh_token = reply.get('refresh_token', self.refresh_token)
        device_grant = reply.get('device_grant', self.device_grant)
        if (not valid_token(access_token) or not valid_token(refresh_token)
                or type(expires_in) is not int or expires_in <= 0):
            raise CloudError('Huawei authorization did not provide usable tokens and expiry')
        self.token = access_token
        self.expires_at = time.monotonic() + expires_in - min(60, expires_in / 10)
        if self.device_gate and device_grant and not valid_token(device_grant):
            raise CloudError('The Biandan renewal service returned an invalid device credential')
        if refresh_token != self.refresh_token or device_grant != self.device_grant:
            self.pending_save = refresh_token, device_grant
            self.persist()

    def access_token(self, *, rejected=None):
        with self.lock:
            if self.signing_in:
                raise CloudError('Complete Huawei authorization in your browser, then retry the tool.')
            if self.pending_save is not None:
                self.persist()
                self.sign_in_error = None
            if self.sign_in_error:
                raise CloudError(self.sign_in_error)
            if self.token and self.token != rejected and time.monotonic() < self.expires_at:
                return self.token
            if self.refresh_token is None:
                self.start_sign_in()
                raise CloudError('Complete Huawei authorization in your browser, then retry the tool.')
            body = json.dumps({'refresh_token': self.refresh_token}).encode('ascii')
            headers = {'Content-Type': 'application/json'}
            endpoint = self.endpoint
            if self.device_gate:
                if self.device_grant:
                    headers['Authorization'] = f'Bearer {self.device_grant}'
                else:
                    endpoint = self.endpoint.removesuffix('/v1/refresh') + '/v1/device'
            try:
                reply = request_json('POST', endpoint, headers, body)
            except CloudError as error:
                if error.status != 401 or error.code != 'reauthorization_required':
                    raise CloudError('The Biandan renewal service is temporarily unavailable. Retry later.') from None
                try:
                    self.store.clear()
                except OSError:
                    raise CloudError('Could not clear the expired local Huawei credential') from None
                self.token = self.refresh_token = self.device_grant = None
                self.start_sign_in()
                raise CloudError('Huawei authorization expired or was revoked. Authorize in the browser, then retry.') from None
            if self.device_gate and not reply.get('device_grant'):
                raise CloudError('The Biandan renewal service did not issue a device credential')
            self.accept(reply)
            return self.token
