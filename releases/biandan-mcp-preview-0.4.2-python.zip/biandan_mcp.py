"""Run Biandan as a local stdio MCP server or call one business tool from the CLI."""

import argparse
from contextlib import ExitStack
import json
import math
import os
from pathlib import Path
import sys
from threading import Lock, Thread
from urllib.parse import urlsplit

from biandan_cloud import BiandanCloud, CloudError, WEB_REDIRECT_URI, authorize_from_environment
from biandan_http import DEFAULT_PORT, create_server, http_config, local_access_key
from biandan_recurrence import FILTERS, MODES, UNITS
from biandan_renewal import RenewingAuthorization, renewal_session
from biandan_tools import BiandanTools, ToolError


VERSIONS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")
HTTP_VERSIONS = VERSIONS[:-1]
SERVER_VERSION = "0.4.2"
RENEWAL_URL = "https://auth.biandangroup.com/v1/refresh"


def string(description):
    return {"type": "string", "description": description}


def boolean(description):
    return {"type": "boolean", "description": description}


def integer(description, minimum, maximum=None):
    schema = {"type": "integer", "description": description, "minimum": minimum}
    if maximum is not None:
        schema["maximum"] = maximum
    return schema


def tool(name, description, properties=None, required=(), *, read_only=True, destructive=False, constraints=()):
    return {
        "name": f"biandan_{name}",
        "description": description,
        "inputSchema": {
            "type": "object", "properties": properties or {}, "required": list(required),
            "additionalProperties": False,
            **({"allOf": list(constraints)} if constraints else {}),
        },
        "annotations": {"readOnlyHint": read_only, "destructiveHint": destructive,
                        "openWorldHint": name not in ("local_today", "help")},
    }


def requires(field, *required):
    return {"if": {"required": [field]}, "then": {"required": list(required)}}


def together(first, second):
    return (requires(first, second), requires(second, first))


def when(field, value, *, required=(), forbidden=(), otherwise_forbidden=()):
    condition = {"required": [field], "properties": {field: {"const": value}}}
    result = {"if": condition, "then": {"required": list(required), **forbid(*forbidden)}}
    if otherwise_forbidden:
        result["else"] = forbid(*otherwise_forbidden)
    return result


def forbid(*fields):
    return {"not": {"anyOf": [{"required": [field]} for field in fields]}} if fields else {}


TASK_ID = string("Biandan task business ID returned as task_id.")
OCCURRENCE_ID = string("Biandan occurrence business ID returned as occurrence_id.")
LIST_ID = string("Biandan list business ID. Use '1' for 未分类.")
START = string("Local start date in YYYY-MM-DD.")
END = string("Inclusive local end date in YYYY-MM-DD. Defaults to the start date.")
START_TIME = string("Local start time in HH:MM.")
END_TIME = string("Local end time in HH:MM.")
IMPORTANT = boolean("Whether the task is important.")
URGENT = boolean("Whether the task is urgent.")
COLLECTED = boolean("Whether the task is collected.")
HABIT = boolean("Filter habits independently of repeating. Habits are a subset of recurring tasks; habit=true and repeating=false yields no results for normal records.")
REPEATING = boolean("Filter recurring tasks, including habits. Combines with the independent habit filter.")
FOCUS_ID = string("Focus record business ID returned as focus_id.")
OPERATION_ID = string("Optional positive numeric business ID (task_id or list_id); generated if omitted and returned on success. Retry a partial creation with the same operation_id and identical inputs. Conflicting existing records are rejected.")
LIST_COLOR = integer("Palette index. 0=default; 1–8=vivid, 9–16=muted, 17–24=Morandi. Within each group: red, orange, yellow, green, lake blue, light blue, dark blue, purple.", 0, 24)
LIST_SORT = integer("Ascending sort index, smaller comes first. Creation defaults to the next index; updates preserve it if omitted. Stored as sort_index * 100 + color.", 0, 999999)
SUBTASKS = {"type": "array", "items": {"type": "string"}, "maxItems": 20,
            "description": "Subtask titles in display order. A nonempty checklist uses a goal bitmask instead of a numeric target_count."}
TARGET_COUNT = integer("Numeric completion target for a count-based task. A nonempty checklist uses the same stored goal field, so it cannot be combined with target_count.", 1, 99)
DATE_WINDOW = {"start_date": START, "end_date": END, "start_time": START_TIME, "end_time": END_TIME}
LOCATION_FIELDS = {
    "name": string("Place name or address."),
    "latitude": {"type": "number", "minimum": -90, "maximum": 90, "description": "Latitude in GCJ-02."},
    "longitude": {"type": "number", "minimum": -180, "maximum": 180, "description": "Longitude in GCJ-02."},
    "remind": boolean("Set the location reminder flag. Enabling requires valid new or already stored coordinates; triggering depends on the native device."),
}
LOCATION_KEYS = tuple(LOCATION_FIELDS)
COORDINATE_PAIR = together("latitude", "longitude")
REMINDER_PAIR = together("reminder_date", "reminder_time")
REMINDER_DATE = string("Local reminder date in YYYY-MM-DD. Must be supplied together with reminder_time.")
REMINDER_TIME = string("Local reminder time in HH:MM. Must be supplied together with reminder_date.")
RULE = {
    "type": "object", "required": ["mode"], "additionalProperties": False,
    "description": "Repeat rule. For every Monday use custom, week, dates ['1']; weekly_period spans a full week.",
    "properties": {
        "mode": {"type": "string", "enum": list(MODES), "description": "Repeat preset. Use custom for unit, interval, dates and day_filter."},
        "unit": {"type": "string", "enum": list(UNITS), "description": "Custom recurrence unit; defaults to day."},
        "interval": integer("Step between custom periods.", 1, 366),
        "dates": {"type": "array", "items": {"type": "string"}, "maxItems": 366,
                  "description": "Strings. day: omit or pass []; week: 0=Sunday to 6=Saturday; month: 1–31 or 32=month end; year: valid MM-DD; lunar_month: 1–30; lunar_year: MM-DD with month 01–12 and day 01–30. Non-day custom units require a nonempty array."},
        "day_filter": {"type": "string", "enum": list(FILTERS), "description": "Custom rule date filter; defaults to all."},
        "duration_days": integer("Length of each occurrence. Ignored by weekly_period, monthly_period and yearly_period because each spans its entire calendar period.", 1, 366),
    },
}
CALENDAR_OPTIONS = {
    "week_start": integer("0=Sunday (default), 1=Monday. Use the native client's setting.", 0, 1),
    "china_makeup": boolean("Use the native Chinese holiday adjustments for 2024–2026."),
}
FOCUS_FIELDS = {"title": string("Optional title or note."),
                "good_count": integer("Number of successful Pomodoros.", 0, 2147483647),
                "bad_count": integer("Number of interrupted Pomodoros.", 0, 2147483647)}
COMPLETED_AT = string("Optional local timestamp YYYY-MM-DDTHH:MM for backfilling a check-in.")
TITLE = string("Task title.")
REMARK = string("Task remark, without attachments or subtask titles.")
PAGINATION = {
    "limit": integer("Max results to return, default 30.", 1, 100),
    "offset": integer("Offset returned as next_offset from the previous call.", 0),
}

TOOLS = [
    tool("help", "精简便单工具用法。省略 tool 查看常用流程，传工具名只返回该操作的参数和示例，无需登录。", {
        "tool": string("可选，工具名，如 biandan_complete_occurrence，也接受 complete_occurrence。"),
    }),
    tool("check_connection", "Check whether the configured credential can connect to Biandan cloud."),
    tool("local_today", "Get the local calendar date of the computer running Biandan."),
    tool("list_lists", "List all Biandan lists with their business IDs and colors."),
    tool("search_tasks", "Find task definitions by title, remark or subtask, including undated tasks.", {
        "query": string("Case-insensitive keyword. Omit to list task definitions."),
        "list_id": LIST_ID, "important": IMPORTANT, "urgent": URGENT, "habit": HABIT, "repeating": REPEATING,
        "completed": boolean("Filter the task's aggregate completion state."), "collected": COLLECTED, **PAGINATION,
    }),
    tool("get_task", "Read a task definition and its subtask titles.", {"task_id": TASK_ID}, ("task_id",)),
    tool("list_occurrences", (
        "List actual task occurrences, for example today's pending tasks or last week's completions. "
        "Completed results filter by completion date; other statuses filter by scheduled date."
    ), {
        "start_date": START, "end_date": END,
        "status": {**string("Status filter; defaults to pending."),
                   "enum": ["pending", "completed", "abandoned", "all"]},
        "task_id": TASK_ID, "list_id": LIST_ID, "important": IMPORTANT, "urgent": URGENT,
        "query": string("Filter by keyword in the task's title, remark or subtask."),
        "habit": HABIT, "repeating": REPEATING, "collected": COLLECTED,
        "time_query": {"type": "string", "enum": ["today", "tomorrow", "last24hour", "next24hour", "last7day", "next7day"],
                       "description": "Relative range in the MCP machine's local time. Mutually exclusive with start_date and end_date."},
        "include_undated": boolean("Also include tasks without a scheduled date, default false."),
        "include_summary": boolean("Include counts by status for all matching occurrences before pagination."),
        **PAGINATION,
    }, constraints=({
        "if": {"required": ["time_query"]}, "then": forbid("start_date", "end_date"),
    })),
    tool("create_task", (
        "Create a one-off or repeating task and its occurrences. Repeat rules need both start_date and end_date. "
        "If the write reports operation_id and a possible partial result, use the same ID and inputs to retry."
    ), {
        "title": TITLE, "remark": REMARK, "list_id": LIST_ID, "important": IMPORTANT, "urgent": URGENT,
        **DATE_WINDOW, "end_date": string("Inclusive local end date. Required with repeat_rule; otherwise defaults to start_date."),
        "subtasks": SUBTASKS, "target_count": TARGET_COUNT,
        "reminder_date": REMINDER_DATE, "reminder_time": REMINDER_TIME,
        "operation_id": OPERATION_ID, "repeat_rule": RULE, "habit": boolean("Marks this series as a habit. true requires repeat_rule."),
        "location": {
            "type": "object", "properties": LOCATION_FIELDS, "additionalProperties": False, "minProperties": 1,
            "description": "Initial place, GCJ-02 coordinate pair or reminder setting. remind=true requires both coordinates. Use set_location to clear later.",
            "allOf": [*COORDINATE_PAIR, when("remind", True, required=("latitude", "longitude"))],
        },
        **CALENDAR_OPTIONS,
    }, ("title",), read_only=False, constraints=(
        *REMINDER_PAIR, requires("repeat_rule", "start_date", "end_date"),
        when("habit", True, required=("repeat_rule",)), requires("reminder_time", "start_date"),
        *(requires(field, "start_date") for field in ("end_date", "start_time", "end_time")),
        {"if": {"required": ["subtasks"], "properties": {"subtasks": {"minItems": 1}}},
         "then": forbid("target_count")},
    )),
    tool("update_task", "Edit task text, priority or collection flag. Editing a remark preserves attachments and subtasks.", {
        "task_id": TASK_ID, "title": TITLE, "remark": REMARK, "important": IMPORTANT,
        "urgent": URGENT, "collected": COLLECTED,
    }, ("task_id",), read_only=False),
    tool("move_task", "Move a task into a specified Biandan list.", {
        "task_id": TASK_ID, "list_id": LIST_ID,
    }, ("task_id", "list_id"), read_only=False),
    tool("reschedule_task", (
        "Change the date of a pending one-off task. Existing clock times are kept if omitted. "
        "The reminder retains its original date/time. Repeating series are not supported."
    ), {
        "task_id": TASK_ID, "start_date": START, "end_date": END,
        "start_time": START_TIME, "end_time": END_TIME,
    }, ("task_id", "start_date"), read_only=False),
    tool("complete_occurrence", "Mark one occurrence complete, including its outstanding subtask or count targets.", {
        "occurrence_id": OCCURRENCE_ID, "completed_at": COMPLETED_AT,
    }, ("occurrence_id",), read_only=False),
    tool("complete_subtask", "Check off one subtask on the selected occurrence.", {
        "occurrence_id": OCCURRENCE_ID,
        "subtask_index": integer("Zero-based position in the task's subtask list.", 0, 19),
    }, ("occurrence_id", "subtask_index"), read_only=False),
    tool("get_list", "Read a list and optionally its pending occurrences.", {
        "list_id": LIST_ID, "include_pending": boolean("Include paginated pending occurrences."), **PAGINATION,
    }, ("list_id",)),
    tool("create_list", "Create a list, optionally with a color and sort index.", {
        "name": string("List name."), "color": LIST_COLOR,
        "sort_index": LIST_SORT, "operation_id": OPERATION_ID,
    }, ("name",), read_only=False),
    tool("update_list", "Rename, recolor or reorder a list.", {
        "list_id": LIST_ID, "name": string("List name."), "color": LIST_COLOR,
        "sort_index": LIST_SORT,
    }, ("list_id",), read_only=False),
    tool("delete_list", "Delete a list. List 1 (未分类) is protected.", {
        "list_id": LIST_ID, "tasks": {"type": "string", "enum": ["move_to_default", "delete_tasks"],
                                    "description": "move_to_default (default) moves tasks to 未分类. delete_tasks permanently deletes their task definitions and occurrences."},
        "preview": boolean("No writes. Returns preview, list_id, task_action and affected_tasks (task_id and title)."),
    }, ("list_id",), read_only=False, destructive=True),
    tool("delete_task", "Delete a task or selected occurrences. Permanent; repeating tasks require an explicit scope.", {
        "task_id": TASK_ID, "scope": {"type": "string", "enum": ["occurrence", "future_pending", "series"],
            "description": "Required for repeats. occurrence deletes the selected occurrence and, for a one-off, its task; requires occurrence_id. future_pending deletes unfinished occurrences starting at the cutoff and the task if this removes all instances. series deletes the whole task and its instances. A one-off defaults to series."},
        "occurrence_id": string("Required only with scope=occurrence; forbidden in other scopes."),
        "from_date": string("Only with future_pending. Inclusive local YYYY-MM-DD at midnight. If omitted, uses the MCP machine's current local time."),
        "preview": boolean("No writes. Returns preview, task_id, title, scope, occurrence_ids and deletes_task_definition."),
    }, ("task_id",), read_only=False, destructive=True, constraints=(
        when("scope", "occurrence", required=("occurrence_id",), otherwise_forbidden=("occurrence_id",)),
        when("scope", "future_pending", otherwise_forbidden=("from_date",)),
    )),
    tool("update_recurrence", "Change a repeat rule or convert a task. Keep history and rebuild eligible future occurrences.", {
        "task_id": TASK_ID, "repeat_rule": RULE, "from_date": START, **DATE_WINDOW,
        "start_date": string("Local series start date. Required with end_date when converting an undated task; otherwise retains the stored start date."),
        "end_date": string("Inclusive series end date. Required with start_date when converting an undated task; otherwise retains the stored end date."),
        "habit": boolean("Change whether the repeat series is shown as a habit."), **CALENDAR_OPTIONS,
        "preview": boolean("No writes. Returns preview, task_id, from_date and counts: created, rescheduled, removed, protected_dates."),
    }, ("task_id", "repeat_rule"), read_only=False, destructive=True),
    tool("get_occurrence", "Read one exact occurrence, with its task definition and progress.", {
        "occurrence_id": OCCURRENCE_ID,
    }, ("occurrence_id",)),
    tool("reschedule_occurrence", "Reschedule one pending occurrence, detaching it from a repeat series.", {
        "occurrence_id": OCCURRENCE_ID, **DATE_WINDOW,
    }, ("occurrence_id", "start_date"), read_only=False),
    tool("clear_schedule", "Clear dates and the time reminder of a one-off task.", {
        "task_id": TASK_ID,
    }, ("task_id",), read_only=False),
    tool("set_location", "Set, clear or change a task's location and independently toggle its location reminder.", {
        "task_id": TASK_ID, **LOCATION_FIELDS, "clear": boolean("true clears place, coordinates and location reminder. Omit name, latitude, longitude and remind when clearing."),
    }, ("task_id",), read_only=False, constraints=(
        *COORDINATE_PAIR, when("clear", True, forbidden=LOCATION_KEYS),
    )),
    tool("set_time_reminder", "Set or disable the time reminder on an existing task.", {
        "task_id": TASK_ID, "reminder_date": REMINDER_DATE, "reminder_time": REMINDER_TIME,
        "enabled": boolean("Defaults to true and requires both date and time. false clears only the time reminder and forbids both date and time."),
    }, ("task_id",), read_only=False, constraints=(
        when("enabled", False, forbidden=("reminder_date", "reminder_time")),
        {"if": {"not": {"required": ["enabled"], "properties": {"enabled": {"const": False}}}},
         "then": {"required": ["reminder_date", "reminder_time"]}},
    )),
    tool("change_progress", "Reopen, abandon, restore, uncheck a subtask or record a numeric progress count.", {
        "occurrence_id": OCCURRENCE_ID,
        "action": {"type": "string", "enum": ["reopen", "abandon", "restore", "uncheck_subtask", "set_count"],
                   "description": "reopen resets progress to zero; abandon skips this occurrence; restore reopens an abandoned occurrence. uncheck_subtask requires a valid checklist index. set_count is for count-based tasks and requires count. Only set_count accepts completed_at."},
        "subtask_index": integer("Zero-based index of a subtask in the goal. Required only for uncheck_subtask.", 0, 19),
        "count": integer("Absolute count, up to the task target. Required only for set_count.", 0, 99),
        "completed_at": string("Optional local YYYY-MM-DDTHH:MM. Only accepted with set_count."),
    }, ("occurrence_id", "action"), read_only=False, constraints=(
        when("action", "uncheck_subtask", required=("subtask_index",), otherwise_forbidden=("subtask_index",)),
        when("action", "set_count", required=("count",), otherwise_forbidden=("count", "completed_at")),
    )),
    tool("edit_task_goal", "Change the goal. Supply exactly one of subtasks or target_count.", {
        "task_id": TASK_ID, "subtasks": SUBTASKS, "target_count": TARGET_COUNT,
    }, ("task_id",), read_only=False, constraints=({"oneOf": [{"required": ["subtasks"]}, {"required": ["target_count"]}]},)),
    tool("list_focus", "List focus records by local date range or linked occurrence.", {
        "start_date": START, "end_date": END, "occurrence_id": OCCURRENCE_ID, **PAGINATION,
        "include_summary": boolean("Sum minutes and Pomodoro counts before pagination."),
    }),
    tool("get_focus", "Read one focus record.", {"focus_id": FOCUS_ID}, ("focus_id",)),
    tool("create_focus", "Log completed focus time. Provide a local start timestamp and a duration.", {
        "started_at": string("Use YYYY-MM-DDTHH:MM, optional seconds, in MCP's local time."),
        "minutes": {"type": "number", "minimum": 1, "maximum": 1440,
                    "description": "Minutes. Fractions are accepted and rounded down before calculating the end time and totals."},
        "occurrence_id": OCCURRENCE_ID, **FOCUS_FIELDS,
    }, ("started_at", "minutes"), read_only=False),
    tool("update_focus", "Change a focus record's title and Pomodoro counts.", {
        "focus_id": FOCUS_ID, **FOCUS_FIELDS,
    }, ("focus_id",), read_only=False),
    tool("delete_focus", "Permanently delete one focus record.", {"focus_id": FOCUS_ID}, ("focus_id",),
         read_only=False, destructive=True),
]


CREATE_TASK_INPUT = next(entry["inputSchema"] for entry in TOOLS if entry["name"] == "biandan_create_task")
UPDATE_TASK_INPUT = next(entry["inputSchema"] for entry in TOOLS if entry["name"] == "biandan_update_task")
TOOLS.extend([
    tool("batch_add_tasks", "Create up to 20 tasks. Results and retry IDs are returned per task.", {
        "tasks": {"type": "array", "minItems": 1, "maxItems": 20, "items": CREATE_TASK_INPUT,
                  "description": "One to 20 create_task argument objects; each needs title. Results are in input order. Check each item for errors and any operation_id."},
    }, ("tasks",), read_only=False),
    tool("batch_update_tasks", "Edit, move or reschedule up to 20 tasks. Results are returned per task.", {
        "tasks": {"type": "array", "minItems": 1, "maxItems": 20,
                  "description": "One to 20 objects with task_id. Combine update_task fields, list_id to move, and date/time fields to reschedule. end_date, start_time and end_time each require start_date. Results are per item.",
                  "items": {**UPDATE_TASK_INPUT, "properties": {
                      **UPDATE_TASK_INPUT["properties"], "list_id": LIST_ID, **DATE_WINDOW},
                      "allOf": [requires(field, "start_date") for field in ("end_date", "start_time", "end_time")]}},
    }, ("tasks",), read_only=False),
    tool("batch_complete_occurrences", "Complete up to 20 exact occurrences. Results are returned per occurrence.", {
        "occurrence_ids": {"type": "array", "minItems": 1, "maxItems": 20, "items": OCCURRENCE_ID,
                           "description": "One to 20 occurrence_id strings from list_occurrences or get_occurrence. Results are in input order."},
    }, ("occurrence_ids",), read_only=False),
])
TOOL_BY_NAME = {entry["name"]: entry for entry in TOOLS}


HELP_EXAMPLES = {
    "check_connection": ({}, "连接通过后再查询真实数据。"),
    "local_today": ({}, "解析「今天」或「明天」时先取运行 MCP 的设备日期。"),
    "list_lists": ({}, "返回 list_id。移动前按名称找到清单；1 是未分类。"),
    "search_tasks": ({"query": "英语"}, "返回任务定义和 task_id。查某日是否要做或是否已完成，请用 list_occurrences。"),
    "get_task": ({"task_id": "123"}, "用 search_tasks 或 list_occurrences 返回的 task_id。子任务按列表顺序从 0 编号。"),
    "list_occurrences": ({"start_date": "2026-11-19", "status": "pending"}, "日期用本机日历。completed 按实际完成日筛选；无日期待办需显式 include_undated。"),
    "create_task": ({"title": "每周阅读", "start_date": "2026-11-20", "end_date": "2026-12-31",
                     "repeat_rule": {"mode": "custom", "unit": "week", "dates": ["1"]}},
                    "省略 repeat_rule 可创建一次性待办。循环需要结束日期，周一填 1。部分写入时用原参数和 operation_id 重试。"),
    "update_task": ({"task_id": "123", "important": True}, "至少传一项改动。改备注会保留子任务和附件。"),
    "move_task": ({"task_id": "123", "list_id": "5"}, "先用 list_lists 确认目标清单 ID，同名时请用户确认。"),
    "reschedule_task": ({"task_id": "123", "start_date": "2026-11-21"}, "限待处理的一次性任务。省略时刻会保留现有时段，原提醒时间不随改期变更。"),
    "complete_occurrence": ({"occurrence_id": "456"}, "先查目标日期的 occurrence_id；只完成当次。"),
    "complete_subtask": ({"occurrence_id": "456", "subtask_index": 0}, "索引从 0 开始。先用 get_task 核对标题顺序，再选具体执行实例。"),
    "get_list": ({"list_id": "5", "include_pending": True}, "先用 list_lists 查 ID。待完成实例可分页。"),
    "create_list": ({"name": "工作", "color": 3}, "颜色为便单色表 0–24。部分写入后用原参数和 operation_id 重试。"),
    "update_list": ({"list_id": "5", "name": "项目工作", "color": 4}, "只修改传入的设置。默认分类受保护。"),
    "delete_list": ({"list_id": "5", "preview": True}, "先预览涉及的任务。默认移回未分类；明确传 delete_tasks 会删除任务与实例。"),
    "delete_task": ({"task_id": "123", "scope": "occurrence", "occurrence_id": "456", "preview": True},
                    "一次性可只传任务 ID。循环选 occurrence（本次）、future_pending（该日期起未完成）或 series（整个系列）。可先预览。"),
    "update_recurrence": ({"task_id": "123", "from_date": "2026-12-01",
                           "repeat_rule": {"mode": "custom", "unit": "week", "dates": ["1", "3"]}, "preview": True},
                          "先预览。截止日前、已完成、有进度或已放弃的实例保留；其余按规则重排。"),
    "get_occurrence": ({"occurrence_id": "456"}, "返回恰好这一次及所属任务。"),
    "reschedule_occurrence": ({"occurrence_id": "456", "start_date": "2026-11-24"}, "只改选中的待执行实例。循环中的当次会另存为一次性任务，实例 ID 和持续天数保留。"),
    "clear_schedule": ({"task_id": "123"}, "清除一次性任务日期和时间提醒，保留地点提醒。"),
    "set_location": ({"task_id": "123", "name": "办公室", "latitude": 31.2, "longitude": 121.4, "remind": True},
                     "坐标使用 GCJ-02，可只传名称。开启地点提醒需已有或同时提供坐标，实际触发由原生设备处理。clear=true 清除地点。"),
    "set_time_reminder": ({"task_id": "123", "reminder_date": "2026-12-01", "reminder_time": "09:00"},
                          "enabled=false 关闭时间提醒并保留地点提醒。"),
    "change_progress": ({"occurrence_id": "456", "action": "uncheck_subtask", "subtask_index": 0},
                        "reopen 撤销并清零；abandon 放弃；restore 恢复已放弃；set_count 写入绝对次数。"),
    "edit_task_goal": ({"task_id": "123", "target_count": 5}, "传次数或完整子任务列表。有历史进度时保留子任务位置。"),
    "batch_add_tasks": ({"tasks": [{"title": "准备讲稿"}, {"title": "检查设备"}]}, "最多 20 项。逐项检查结果，失败项单独重试。"),
    "batch_update_tasks": ({"tasks": [{"task_id": "123", "important": True}, {"task_id": "124", "list_id": "5"}]},
                           "可分别更新文字、优先级、清单或一次性任务日期。"),
    "batch_complete_occurrences": ({"occurrence_ids": ["456", "457"]}, "最多 20 项；使用具体执行实例 ID。"),
    "list_focus": ({"start_date": "2026-12-01", "end_date": "2026-12-07"}, "可按执行实例或本地日期查询专注记录。"),
    "get_focus": ({"focus_id": "1796115600000"}, "使用 list_focus 返回的记录 ID。"),
    "create_focus": ({"started_at": "2026-12-01T09:00", "minutes": 25, "title": "写方案", "good_count": 1},
                     "补记已结束的专注时间。开始时刻是记录标识，可用 occurrence_id 关联某次任务。"),
    "update_focus": ({"focus_id": "1796115600000", "title": "写评审方案"}, "可改标题和番茄数，时间仍按原记录。"),
    "delete_focus": ({"focus_id": "1796115600000"}, "永久删除此条专注记录。"),
    "help": ({"tool": "complete_occurrence"}, "只查当前需要的工具即可。"),
}

PREVIEW_EXAMPLES = {
    "delete_task": {"preview": True, "task_id": "123", "title": "阅读", "scope": "occurrence",
                    "occurrence_ids": ["456"], "deletes_task_definition": False},
    "delete_list": {"preview": True, "list_id": "5", "task_action": "move_to_default",
                    "affected_tasks": [{"task_id": "123", "title": "阅读"}]},
    "update_recurrence": {"preview": True, "task_id": "123", "from_date": "2026-12-01",
                          "created": 3, "rescheduled": 1, "removed": 2, "protected_dates": 4},
}


def tool_help(tool=None):
    if tool is None:
        return {
            "用法": '传 {"tool":"工具名"} 查看该操作的参数和一条示例。',
            "常见流程": [
                "查今天：local_today → list_occurrences",
                "找任务或清单：search_tasks / list_lists",
                "新建：create_task；编辑：update_task / move_task / reschedule_task",
                "完成：list_occurrences 取 occurrence_id → complete_occurrence / complete_subtask",
                "循环与习惯：create_task 传 repeat_rule，可设 habit=true；update_recurrence 预览修改",
                "整理：create_list / update_list / delete_list；批量操作用 batch_add_tasks / batch_update_tasks",
                "查询专注：list_focus；补记：create_focus",
            ],
        }
    short = tool.strip().removeprefix("biandan_")
    if short not in HELP_EXAMPLES:
        raise ToolError("工具名未知。省略 tool 查看常见流程，或用 tools/list 查看准确名称。")
    name = f"biandan_{short}"
    schema = TOOL_BY_NAME[name]["inputSchema"]
    example, note = HELP_EXAMPLES[short]
    descriptions = {key: field["description"] for key, field in schema["properties"].items()
                    if field.get("description")}
    result = {"工具": name, "必填": schema["required"],
              "可选": [key for key in schema["properties"] if key not in schema["required"]],
              "示例": example, "说明": note, "参数说明": descriptions}
    for key in ("location", "repeat_rule"):
        if key in schema["properties"]:
            result[f"{key} 字段"] = {
                field: spec["description"] for field, spec in schema["properties"][key]["properties"].items()
            }
    if short in PREVIEW_EXAMPLES:
        result["预览返回示例"] = PREVIEW_EXAMPLES[short]
    return result


def validate(value, schema, label):
    types = {"object": dict, "string": str, "boolean": bool, "integer": int, "array": list}
    if schema["type"] == "number":
        if type(value) not in (int, float) or (type(value) is float and not math.isfinite(value)):
            raise ToolError(f"{label} must be a finite number.")
    elif type(value) is not types[schema["type"]]:
        raise ToolError(f"{label} must be of type {schema['type']}.")
    if "enum" in schema and value not in schema["enum"]:
        raise ToolError(f"{label} has an invalid value.")
    if ("minimum" in schema and value < schema["minimum"]) or ("maximum" in schema and value > schema["maximum"]):
        raise ToolError(f"{label} is out of range.")
    if "maxItems" in schema and len(value) > schema["maxItems"]:
        raise ToolError(f"{label} exceeds the allowed length.")
    if "minItems" in schema and len(value) < schema["minItems"]:
        raise ToolError(f"{label} must not be empty.")
    if "properties" in schema:
        if set(value) - schema["properties"].keys() or set(schema.get("required", ())) - value.keys():
            raise ToolError(f"{label} contains unknown fields or is missing required fields.")
        for key, item in value.items():
            validate(item, schema["properties"][key], key)
    if "items" in schema:
        for index, item in enumerate(value):
            validate(item, schema["items"], f"{label}[{index}]")


def call_tool(name, arguments, service_factory):
    if not isinstance(name, str) or name not in TOOL_BY_NAME:
        raise ToolError("Unknown Biandan tool.")
    validate(arguments, TOOL_BY_NAME[name]["inputSchema"], "arguments")
    if name == "biandan_help":
        return tool_help(**arguments)
    if name == "biandan_local_today":
        return BiandanTools(None).local_today()
    service = service_factory()
    return getattr(service, name.removeprefix("biandan_"))(**arguments)


def tool_failure(error):
    result = {"error": str(error)}
    if isinstance(error, ToolError):
        result.update(error.details)
    cloud_error = error if isinstance(error, CloudError) else error.__cause__
    if isinstance(cloud_error, CloudError):
        if cloud_error.status is not None:
            result["status"] = cloud_error.status
        if cloud_error.status == 401:
            result["action"] = "Restart MCP with --oauth to sign in again, or refresh the configured BIANDAN_TOKEN."
    return result


def result_content(result, is_error=False):
    return {
        "content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
        "structuredContent": result,
        "isError": is_error,
    }


def rpc_error(request_id, code, message):
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}


class StdioServer:
    def __init__(self, service_factory, *, request_version=None):
        self.service_factory = service_factory
        self.protocol_version = request_version
        self.ready = request_version is not None
        self.stateless = self.ready

    def respond(self, message):
        if not isinstance(message, dict) or message.get("jsonrpc") != "2.0":
            return rpc_error(None, -32600, "Invalid Request")
        method = message.get("method")
        request_id = message.get("id")
        if not isinstance(method, str) or ("id" in message and type(request_id) not in (int, str)):
            return rpc_error(None, -32600, "Invalid Request")
        if "id" not in message:
            if not self.stateless and method == "notifications/initialized" and self.protocol_version:
                self.ready = True
            return None
        params = message.get("params", {})
        if not isinstance(params, dict):
            return rpc_error(request_id, -32602, "Invalid params")
        if method == "initialize":
            version = params.get("protocolVersion")
            if not isinstance(version, str) or (not self.stateless and self.protocol_version is not None):
                return rpc_error(request_id, -32602, "Invalid initialization")
            supported = HTTP_VERSIONS if self.stateless else VERSIONS
            self.protocol_version = version if version in supported else supported[0]
            result = {
                "protocolVersion": self.protocol_version,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "biandan", "version": SERVER_VERSION},
                "instructions": "Call biandan_help with a tool name for concise usage. "
                                "Use task_id for task operations and occurrence_id for completion. "
                                "Dates use the local calendar of the computer running this server.",
            }
        elif method == "ping":
            result = {}
        elif not self.ready:
            return rpc_error(request_id, -32002, "Server not initialized")
        elif method == "tools/list":
            result = {"tools": TOOLS}
        elif method == "tools/call":
            if not isinstance(params.get("name"), str) or params["name"] not in TOOL_BY_NAME:
                return rpc_error(request_id, -32602, "Unknown Biandan tool")
            try:
                result = result_content(call_tool(params["name"], params.get("arguments", {}), self.service_factory))
            except (ToolError, CloudError) as error:
                result = result_content(tool_failure(error), True)
            except (ValueError, KeyError, TypeError, AttributeError):
                result = result_content({"error": "Unexpected cloud record or tool data format."}, True)
            if params["name"] == "biandan_help" or self.protocol_version in {"2024-11-05", "2025-03-26"}:
                result.pop("structuredContent", None)
        else:
            return rpc_error(request_id, -32601, "Method not found")
        return {"jsonrpc": "2.0", "id": request_id, "result": result}

    def run(self, source, destination):
        for line in source:
            try:
                message = json.loads(line.decode("utf-8"))
            except (UnicodeError, ValueError):
                response = rpc_error(None, -32700, "Parse error")
            else:
                response = self.respond(message)
            if response is not None:
                destination.write((json.dumps(response, ensure_ascii=False) + "\n").encode("utf-8"))
                destination.flush()


def service_from_environment():
    token = os.environ.get("BIANDAN_TOKEN", "")
    if not token:
        raise ToolError("BIANDAN_TOKEN is not configured. Provide a locally authorized Huawei access token.")
    return BiandanTools(BiandanCloud(token))


class BrowserAuthorization:
    def __init__(self):
        self.lock = Lock()
        self.started = False
        self.service = None
        self.error = None
        try:
            redirect_uri = os.environ.get("BIANDAN_REDIRECT_URI", WEB_REDIRECT_URI)
            redirect = urlsplit(redirect_uri)
            registered_loopback = redirect.scheme == "http" and redirect.hostname == "127.0.0.1" and redirect.port
        except ValueError:
            redirect_uri = ""
            registered_loopback = False
        if redirect_uri != WEB_REDIRECT_URI and not registered_loopback:
            self.error = "Use the Biandan website relay or a registered 127.0.0.1 callback for MCP --oauth."

    def sign_in(self):
        try:
            service = BiandanTools(BiandanCloud(authorize_from_environment()))
        except (CloudError, OSError, ValueError) as error:
            with self.lock:
                self.error = str(error)
        else:
            with self.lock:
                self.service = service

    def __call__(self):
        with self.lock:
            if self.error is not None:
                raise ToolError(self.error, action="Correct the registration or restart Biandan to authorize again.")
            if self.service is not None:
                return self.service
            if not self.started:
                Thread(target=self.sign_in, daemon=True).start()
                self.started = True
            raise ToolError("Complete Huawei authorization in your browser, then retry the tool.",
                            action="waiting_for_browser_authorization")


def run_http(port):
    access_key = local_access_key()
    lock = Lock()

    def dispatch(message, version):
        rpc = StdioServer(factory, request_version=version)
        if isinstance(message, dict) and message.get("method") == "tools/call":
            params = message.get("params")
            if not isinstance(params, dict) or params.get("name") not in ("biandan_help", "biandan_local_today"):
                # Hold the lock through cloud operations so sessions do not interleave multi-record updates.
                with lock:
                    return rpc.respond(message)
        return rpc.respond(message)

    with ExitStack() as stack:
        server = stack.enter_context(create_server(port, access_key, HTTP_VERSIONS, dispatch))
        endpoint = os.environ.get("BIANDAN_RENEWAL_URL", RENEWAL_URL)
        custom_oauth = any(name in os.environ for name in
                           ("BIANDAN_CLIENT_ID", "BIANDAN_REDIRECT_URI", "BIANDAN_SCOPE"))
        if os.environ.get("BIANDAN_TOKEN"):
            factory = service_from_environment
        elif endpoint and not custom_oauth:
            stack.enter_context(renewal_session())
            authorizer = RenewingAuthorization(endpoint, device_gate=True)
            service = BiandanTools(BiandanCloud(None, authorizer=authorizer))
            def factory():
                return service
        else:
            factory = BrowserAuthorization()
        print(f"Biandan MCP ready: http://127.0.0.1:{port}/mcp", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--list-tools", action="store_true", help="Print tool names and JSON input schemas")
    mode.add_argument("--print-config", action="store_true", help="Print this installation's MCP client configuration")
    mode.add_argument("--print-http-config", action="store_true", help="Print HTTP config with the local access key")
    mode.add_argument("--http", action="store_true", help="Run one shared loopback Streamable HTTP server")
    mode.add_argument("--call", choices=TOOL_BY_NAME, help="Call a tool; pass a JSON argument object on stdin")
    mode.add_argument("--oauth", action="store_true", help="Authorize in the browser when a cloud tool first needs it")
    parser.add_argument("--http-port", type=int, default=DEFAULT_PORT, help="Loopback HTTP port (default: %(default)s)")
    args = parser.parse_args()
    if args.http or args.print_http_config:
        if not 1 <= args.http_port <= 65535:
            parser.error("--http-port must be between 1 and 65535")
        try:
            if args.print_http_config:
                print(json.dumps(http_config(args.http_port, local_access_key()), indent=2))
            else:
                run_http(args.http_port)
        except (CloudError, OSError, ValueError) as error:
            print(f"Could not configure or start local Biandan MCP: {error}", file=sys.stderr)
            return 1
    elif args.print_config:
        launch_args = ["--oauth"]
        if not getattr(sys, "frozen", False):
            launch_args.insert(0, str(Path(__file__).resolve()))
        config = {"mcpServers": {"biandan": {"command": sys.executable, "args": launch_args}}}
        print(json.dumps(config, ensure_ascii=True, indent=2))
    elif args.list_tools:
        print(json.dumps(TOOLS, ensure_ascii=True, indent=2))
    elif args.call:
        try:
            raw = sys.stdin.buffer.read()
            arguments = json.loads(raw.decode("utf-8-sig")) if raw.strip() else {}
            result = call_tool(args.call, arguments, service_from_environment)
        except (ToolError, CloudError) as error:
            print(json.dumps(tool_failure(error), ensure_ascii=True), file=sys.stderr)
            return 1
        except (ValueError, KeyError, TypeError, AttributeError):
            print('{"error":"Invalid JSON arguments or unexpected cloud data format."}', file=sys.stderr)
            return 1
        print(json.dumps(result, ensure_ascii=True))
    else:
        factory = BrowserAuthorization() if args.oauth else service_from_environment
        StdioServer(factory).run(sys.stdin.buffer, sys.stdout.buffer)
    return 0


if __name__ == "__main__":
    sys.exit(main())
