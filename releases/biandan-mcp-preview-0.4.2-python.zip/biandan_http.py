"""Shared loopback Streamable HTTP transport for Biandan MCP."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import time


DEFAULT_PORT = 42682
MAX_BODY = 256 * 1024


def state_directory():
    override = os.environ.get("BIANDAN_MCP_STATE_DIR")
    if override:
        state_dir = Path(override)
    else:
        state_dir = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / ".biandan-mcp"
    return state_dir


def local_access_key():
    state_dir = state_directory()
    state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = state_dir / "http-access-key"
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        for _ in range(10):
            token = path.read_text(encoding="ascii").strip()
            if re.fullmatch(r"[A-Za-z0-9_-]{43}", token):
                return token
            # A second process may have opened the new key file but not written it yet.
            if token:
                break
            time.sleep(0.05)
        raise ValueError(f"Invalid local MCP key at {path}")
    with os.fdopen(fd, "w", encoding="ascii") as target:
        token = secrets.token_urlsafe(32)
        target.write(token)
    return token


def http_config(port, token):
    return {"mcpServers": {"biandan": {
        "url": f"http://127.0.0.1:{port}/mcp",
        "headers": {"Authorization": f"Bearer {token}"},
    }}}


def create_server(port, token, versions, dispatch):
    expected_auth = ("Bearer " + token).encode("ascii")

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, *_):
            pass

        def reply(self, code, message=None, **headers):
            payload = b"" if message is None else json.dumps(message, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            if payload:
                self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            for name, value in headers.items():
                self.send_header(name.replace("_", "-"), value)
            self.end_headers()
            if payload:
                self.wfile.write(payload)

        def authorized(self):
            port_number = self.server.server_port
            hosts = {f"127.0.0.1:{port_number}", f"localhost:{port_number}"}
            origin = self.headers.get("Origin")
            if self.headers.get("Host") not in hosts or (
                origin is not None and origin not in {f"http://{host}" for host in hosts}
            ):
                self.reply(403, {"error": "Only loopback MCP clients are accepted"})
                return False
            if self.path != "/mcp":
                self.reply(404)
                return False
            supplied = self.headers.get("Authorization", "").encode("latin-1")
            if not secrets.compare_digest(supplied, expected_auth):
                self.reply(401, {"error": "Use the Authorization header from --print-http-config"},
                           WWW_Authenticate='Bearer realm="Biandan local MCP"')
                return False
            return True

        def do_POST(self):
            if not self.authorized():
                return
            version = self.headers.get("MCP-Protocol-Version", "2025-03-26")
            if version not in versions:
                self.reply(400, {"error": "Unsupported MCP protocol version"})
                return
            if self.headers.get_content_type() != "application/json":
                self.reply(415, {"error": "Use application/json"})
                return
            try:
                length = int(self.headers.get("Content-Length", "-1"))
            except ValueError:
                length = -1
            if length < 0 or self.headers.get("Transfer-Encoding"):
                self.reply(400, {"error": "A valid Content-Length is required"})
                return
            if length > MAX_BODY:
                self.reply(413, {"error": "MCP request too large"})
                return
            try:
                message = json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, UnicodeError):
                self.reply(400, {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}})
                return
            response = dispatch(message, version)
            if response is None:
                self.reply(202)
            elif response.get("error", {}).get("code") == -32600:
                self.reply(400, response)
            else:
                self.reply(200, response)

        def method_not_supported(self):
            if self.authorized():
                self.reply(405, Allow="POST")

        # Requests return JSON directly. No server-initiated SSE stream or session ID.
        do_GET = do_DELETE = do_OPTIONS = method_not_supported

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)
